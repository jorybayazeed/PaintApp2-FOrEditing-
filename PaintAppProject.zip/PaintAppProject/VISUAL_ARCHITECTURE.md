# 📊 VISUAL ARCHITECTURE - Decorator & Composite Patterns

## 🗂️ PROJECT STRUCTURE

```
PaintAppProject/
│
├── Javafx-Paint-Application/
│   └── Paint/Paint/
│       └── src/paint/
│           │
│           ├── model/
│           │   ├── iShape.java                    [Interface - all implement this]
│           │   ├── Shape.java                     [Abstract base for shapes]
│           │   │
│           │   ├── Circle.java                    [Base Shape 1]
│           │   ├── Rectangle.java                 [Base Shape 2]
│           │   ├── Line.java                      [Base Shape 3]
│           │   ├── Triangle.java                  [Base Shape 4]
│           │   ├── Square.java                    [Base Shape 5]
│           │   ├── Ellipse.java                   [Base Shape 6]
│           │   │
│           │   ├── ⭐ ShapeDecorator.java         [DECORATOR ABSTRACT BASE]
│           │   ├── ⭐ ShapeWithStroke.java        [DECORATOR 1: Stroke]
│           │   ├── ⭐ ShapeWithShadow.java        [DECORATOR 2: Shadow]
│           │   ├── ⭐ ShapeWithGradient.java      [DECORATOR 3: Gradient]
│           │   │
│           │   └── ⭐ ShapeGroup.java             [COMPOSITE: Grouping]
│           │
│           ├── controller/
│           │   ├── FXMLDocumentController.java    [UI Controller]
│           │   ├── DrawingEngine.java             [Stores & draws shapes]
│           │   ├── ShapeFactory.java              [Creates base shapes]
│           │   ├── SaveToXML.java                 [Saves shapes to XML]
│           │   └── LoadFromXML.java               [Loads shapes from XML]
│           │
│           └── view/
│               ├── FXMLDocument.fxml              [UI Layout]
│               └── styles.css                     [Styling]
│
└── DECORATOR_COMPOSITE_LOCATION_GUIDE.md         [📖 This guide]
└── PATTERNS_QUICK_REFERENCE.md                   [📖 Quick ref]
```

---

## 🎨 DECORATOR PATTERN - Visual Flow

### Single Shape + Multiple Decorators

```
                    DECORATOR CHAIN
                    ──────────────

┌─────────────────────────────────────────────────┐
│        User Creates Circle                      │
│        new Circle(p1, p2, Color.RED)           │
└────────────────┬────────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────────────┐
│     ShapeWithStroke(circle, 2.0)                │
│     • wrappedShape = circle                     │
│     • strokeWidth = 2.0                         │
│     • Adds stroke styling                       │
└────────────────┬────────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────────────┐
│     ShapeWithShadow(strokedCircle, 4.0)         │
│     • wrappedShape = strokedCircle              │
│     • shadowOffset = 4.0                        │
│     • Adds shadow effect on top of stroke       │
└────────────────┬────────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────────────┐
│     ShapeWithGradient(shadowedCircle, ...)      │
│     • wrappedShape = shadowedCircle             │
│     • colorStart = Color.RED                    │
│     • colorEnd = Color.YELLOW                   │
│     • Adds gradient fill on top of shadow       │
└────────────────┬────────────────────────────────┘
                 │
                 ▼
        ┌────────────────────┐
        │  Final Result:     │
        │ Gradient Shadow    │
        │ Stroke Circle      │
        └────────────────────┘
```

### Decorator Inheritance Hierarchy

```
                    iShape (interface)
                        ▲
                        │
                        │ implements
                        │
                ┌───────┴──────────┐
                │                  │
        ┌─────────────┐    ┌──────────────────┐
        │   Shape     │    │ ShapeDecorator   │
        │  (abstract) │    │  (abstract)      │
        └─────────────┘    └────────┬─────────┘
            ▲                       │
            │                       │ implements/extends
        ┌───┴────┬────┬────┬────┐  │
        │        │    │    │    │  │
      Circle  Rect  Line Line Tri  │
                                   │
                    ┌──────────────┼──────────────┐
                    │              │              │
            ┌─────────────────┐ ┌──────────────┐ ┌───────────────┐
            │ ShapeWithStroke │ │ShapeWithShadow│ │ShapeWithGradient│
            │ extends Decorator│ │extends Decorator│ │extends Decorator│
            └─────────────────┘ └──────────────┘ └───────────────┘
```

---

## 📦 COMPOSITE PATTERN - Visual Structure

### ShapeGroup Contains Multiple Shapes

```
┌────────────────────────────────────────────┐
│          ShapeGroup (iShape)                │
│   Composite: Can contain any iShape        │
│                                            │
│  Private List<iShape> shapes = [...]       │
│                                            │
│  ┌──────────────────────────────────────┐ │
│  │ Shape 1: Circle (decorated)          │ │
│  │   └─ ShapeWithStroke wrapper         │ │
│  ├──────────────────────────────────────┤ │
│  │ Shape 2: Rectangle (decorated)       │ │
│  │   └─ ShapeWithGradient wrapper       │ │
│  ├──────────────────────────────────────┤ │
│  │ Shape 3: Line (decorated)            │ │
│  │   └─ ShapeWithShadow wrapper         │ │
│  ├──────────────────────────────────────┤ │
│  │ Shape 4: ShapeGroup (NESTED!)        │ │
│  │   ├─ Triangle (decorated)            │ │
│  │   └─ Square (decorated)              │ │
│  └──────────────────────────────────────┘ │
│                                            │
│  Methods:                                  │
│  • draw() → draws all shapes               │
│  • setPosition() → moves all               │
│  • setColor() → colors all                 │
│  • addShape() → adds new shape             │
│  • removeShape() → removes shape           │
│  • clone() → clones all contained shapes   │
└────────────────────────────────────────────┘
```

### Composite Nesting (Groups within Groups)

```
                    ROOT GROUP
                    ──────────
                        │
        ┌───────────────┼───────────────┐
        │               │               │
    ┌───▼───┐       ┌───▼───┐      ┌───▼────┐
    │Circle │       │Rect   │      │GROUP 2  │  ← Nested Group
    └───────┘       │Dashed │      │ ┌────┐ │
                    │Stroke │      │ │Line│ │
                    └───────┘      │ │Grd │ │
                                   │ └────┘ │
                                   │ ┌────┐ │
                                   │ │Tri │ │
                                   │ └────┘ │
                                   └────────┘

    When you draw ROOT GROUP:
    1. Draw Circle
    2. Draw Rect with stroke
    3. Draw nested GROUP 2:
       - Draw Line with gradient
       - Draw Triangle
```

---

## 🔄 COMBINING DECORATOR + COMPOSITE

### Complex Example: Shapes with Effects in a Group

```
                    USER'S PERSPECTIVE
                    ──────────────────

    I want to:
    1. Draw a circle with a stroke
    2. Draw a rectangle with a gradient
    3. Draw a line with a shadow
    4. Group them all together
    5. Move/color the entire group


                    CODE STRUCTURE
                    ──────────────

    Step 1: Create decorated shapes
    ┌─────────────────────────────────────┐
    │ iShape circle = new Circle(...)     │
    │ iShape decoratedCircle =            │
    │   new ShapeWithStroke(circle, 2.0)  │
    └─────────────────────────────────────┘

    Step 2: Create more decorated shapes
    ┌─────────────────────────────────────┐
    │ iShape rectangle = new Rectangle(...) │
    │ iShape decoratedRect =              │
    │   new ShapeWithGradient(rectangle, │
    │       Color.RED, Color.BLUE)        │
    └─────────────────────────────────────┘

    Step 3: Create group and add decorated shapes
    ┌─────────────────────────────────────┐
    │ ShapeGroup group = new ShapeGroup() │
    │ group.addShape(decoratedCircle)     │
    │ group.addShape(decoratedRect)       │
    │ group.addShape(decoratedLine)       │
    └─────────────────────────────────────┘

    Step 4: Draw entire group (all decorations applied)
    ┌─────────────────────────────────────┐
    │ group.draw(canvas)                  │
    │ // Draws all 3 with their effects   │
    └─────────────────────────────────────┘

    Step 5: Operations on entire group
    ┌─────────────────────────────────────┐
    │ group.setPosition(new Point2D(...)) │
    │ // Moves ALL shapes                 │
    │                                     │
    │ group.setColor(Color.BLACK)         │
    │ // Colors ALL shapes                │
    │                                     │
    │ iShape clonedGroup = group.clone()  │
    │ // Clones ALL decorated shapes      │
    └─────────────────────────────────────┘
```

---

## 🎯 HOW TO USE IN YOUR PAINT APP

### Current Flow (Before Patterns)
```
User draws → Factory creates shape → Engine stores → Engine draws
```

### Enhanced Flow (With Patterns)
```
User draws
    ↓
Factory creates shape
    ↓
Check decorator options → Wrap in decorators
    ↓
Check group option → Add to group
    ↓
Engine stores (single shape or group)
    ↓
Engine draws (single shape or entire group with all effects)
```

---

## 📝 KEY FILES TO UNDERSTAND

| File | Pattern | Purpose | Key Line |
|------|---------|---------|----------|
| ShapeDecorator.java | Decorator | Base for all decorators | Line 20: `protected iShape wrappedShape;` |
| ShapeWithStroke.java | Decorator | Adds stroke | Line 38: `gc.setLineWidth(strokeWidth);` |
| ShapeWithShadow.java | Decorator | Adds shadow | Line 43: `gc.setFill(shadowColor);` |
| ShapeWithGradient.java | Decorator | Adds gradient | Line 58: `gc.setFill(gradient);` |
| ShapeGroup.java | Composite | Groups shapes | Line 80: `for (iShape shape : shapes)` |

---

## 🚀 NEXT INTEGRATION STEPS

### 1. FXMLDocumentController.java
Add these imports:
```java
import paint.model.ShapeWithStroke;
import paint.model.ShapeWithShadow;
import paint.model.ShapeWithGradient;
```

Add these UI elements:
```xml
<CheckBox fx:id="strokeCheckbox" text="Add Stroke"/>
<Spinner fx:id="strokeWidth" />
<CheckBox fx:id="shadowCheckbox" text="Add Shadow"/>
<CheckBox fx:id="gradientCheckbox" text="Add Gradient"/>
<Button fx:id="groupButton" text="Group Selected"/>
```

### 2. DrawingEngine.java
Add grouping support:
```java
public void groupShapes(List<iShape> shapes) {
    ShapeGroup group = new ShapeGroup();
    for (iShape shape : shapes) {
        group.addShape(shape);
    }
    // Add group to drawing
}
```

### 3. SaveToXML.java / LoadFromXML.java
Add serialization for decorators/groups (advanced step)

