
package paint;

import java.io.IOException;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;

public class Paint extends Application {
    
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("view/FXMLDocument.fxml"));
        
        Scene scene = new Scene(root);
        scene.getStylesheets().add(getClass().getResource("view/styles.css").toExternalForm());
        
        stage.setScene(scene);
        stage.setMinHeight(1050);
        stage.setMinWidth(1600);
        stage.setHeight(1050);
        stage.setWidth(1600);
        stage.show();
    }

   
    public static void main(String[] args)  {
        launch(args);
        
    }
}
