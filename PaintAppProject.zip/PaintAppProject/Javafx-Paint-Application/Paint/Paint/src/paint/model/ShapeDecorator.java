package paint.model;

import javafx.geometry.Point2D;
import javafx.scene.canvas.Canvas;
import javafx.scene.paint.Color;

/**
 * DECORATOR PATTERN - Abstract Base Class
 * 
 * This abstract class defines the interface for decorators that add
 * responsibilities to Shape objects dynamically at runtime.
 * 
 * The Decorator pattern allows us to:
 * 1. Add new features to shapes without modifying their classes
 * 2. Combine multiple decorators (composition)
 * 3. Apply features dynamically at runtime
 * 
 * Example: A circle can become (stroke + shadow + gradient) by wrapping it
 */
public abstract class ShapeDecorator implements iShape {
    
    // The wrapped shape - composition principle
    protected iShape wrappedShape;
    
    public ShapeDecorator(iShape shape) {
        this.wrappedShape = shape;
    }
    
    // Delegate all methods to wrapped shape by default
    // Subclasses override specific methods to add behavior
    
    @Override
    public void setPosition(Point2D position) {
        wrappedShape.setPosition(position);
    }
    
    @Override
    public Point2D getPosition() {
        return wrappedShape.getPosition();
    }
    
    @Override
    public void setColor(Color color) {
        wrappedShape.setColor(color);
    }
    
    @Override
    public Color getColor() {
        return wrappedShape.getColor();
    }
    
    @Override
    public void setFillColor(Color color) {
        wrappedShape.setFillColor(color);
    }
    
    @Override
    public Color getFillColor() {
        return wrappedShape.getFillColor();
    }
    
    @Override
    public void draw(Canvas canvas) {
        // Base implementation - subclasses override to add effects
        wrappedShape.draw(canvas);
    }
    
    @Override
    public abstract iShape clone() throws CloneNotSupportedException;
    
    @Override
    public void setProperties(java.util.Map<String, Double> properties) {
        wrappedShape.setProperties(properties);
    }
    
    @Override
    public java.util.Map<String, Double> getProperties() {
        return wrappedShape.getProperties();
    }
}
