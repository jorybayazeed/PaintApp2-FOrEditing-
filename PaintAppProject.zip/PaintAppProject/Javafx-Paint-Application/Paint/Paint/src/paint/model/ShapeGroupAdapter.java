package paint.model;

import java.util.Map;
import javafx.geometry.Point2D;
import javafx.scene.canvas.Canvas;
import javafx.scene.paint.Color;

/**
 * ADAPTER PATTERN - ShapeGroupAdapter
 * 
 * This class adapts ShapeGroup (which implements iShape)
 * to work with the existing Shape interface in the controller.
 * 
 * This allows ShapeGroup to be stored in the shapeList
 * without breaking the existing code structure.
 */
public class ShapeGroupAdapter extends Shape {
    
    private ShapeGroup group;
    
    public ShapeGroupAdapter(ShapeGroup group) {
        this.group = group;
    }
    
    @Override
    public void draw(Canvas canvas) {
        if (group != null) {
            group.draw(canvas);
        }
    }
    
    @Override
    public void setPosition(Point2D topLeft) {
        if (group != null) {
            group.setPosition(topLeft);
        }
    }
    
    @Override
    public Point2D getPosition() {
        if (group != null) {
            return group.getPosition();
        }
        return new Point2D(0, 0);
    }
    
    @Override
    public void setColor(Color color) {
        if (group != null) {
            group.setColor(color);
        }
    }
    
    @Override
    public Color getColor() {
        if (group != null) {
            return group.getColor();
        }
        return Color.BLACK;
    }
    
    @Override
    public void setFillColor(Color color) {
        if (group != null) {
            group.setFillColor(color);
        }
    }
    
    @Override
    public Color getFillColor() {
        if (group != null) {
            return group.getFillColor();
        }
        return Color.TRANSPARENT;
    }
    
    @Override
    public void setTopLeft(Point2D topLeft) {
        if (group != null) {
            group.setTopLeft(topLeft);
        }
    }
    
    @Override
    public Point2D getTopLeft() {
        if (group != null) {
            return group.getTopLeft();
        }
        return new Point2D(0, 0);
    }
    
    @Override
    public void setProperties(Map<String, Double> properties) {
        if (group != null) {
            group.setProperties(properties);
        }
    }
    
    @Override
    public Map<String, Double> getProperties() {
        if (group != null) {
            return group.getProperties();
        }
        return super.getProperties();
    }
    
    @Override
    public Shape clone() throws CloneNotSupportedException {
        if (group != null) {
            iShape clonedGroup = group.clone();
            return new ShapeGroupAdapter((ShapeGroup)clonedGroup);
        }
        return super.clone();
    }
    
    public ShapeGroup getGroup() {
        return group;
    }
}
