package paint.model;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

/**
 * CONCRETE DECORATOR 1: ShapeWithStroke
 * 
 * This decorator adds stroke styling to any shape.
 * 
 * Usage:
 *   iShape circle = new Circle(start, end, color);
 *   iShape styledCircle = new ShapeWithStroke(circle, 3.0);
 */
public class ShapeWithStroke extends ShapeDecorator {
    
    private double strokeWidth;
    private String strokeStyle; // "solid", "dashed", "dotted"
    
    public ShapeWithStroke(iShape shape, double strokeWidth) {
        super(shape);
        this.strokeWidth = strokeWidth;
        this.strokeStyle = "solid";
    }
    
    public ShapeWithStroke(iShape shape, double strokeWidth, String style) {
        super(shape);
        this.strokeWidth = strokeWidth;
        this.strokeStyle = style;
    }
    
    @Override
    public void draw(Canvas canvas) {
        GraphicsContext gc = canvas.getGraphicsContext2D();
        
        // Save original stroke width
        double originalWidth = gc.getLineWidth();
        
        // Apply new stroke width
        gc.setLineWidth(strokeWidth);
        
        // Apply stroke style
        if ("dashed".equals(strokeStyle)) {
            gc.setLineDashes(5, 5);
        } else if ("dotted".equals(strokeStyle)) {
            gc.setLineDashes(2, 3);
        } else {
            gc.setLineDashes(); // solid
        }
        
        // Draw the wrapped shape with new stroke
        wrappedShape.draw(canvas);
        
        // Restore original stroke width
        gc.setLineWidth(originalWidth);
        gc.setLineDashes();
    }
    
    public void setStrokeWidth(double width) {
        this.strokeWidth = width;
    }
    
    public double getStrokeWidth() {
        return strokeWidth;
    }
    
    @Override
    public iShape clone() throws CloneNotSupportedException {
        iShape clonedInner = (wrappedShape != null) ? wrappedShape.clone() : null;
        return (iShape) new ShapeWithStroke(clonedInner, this.strokeWidth, this.strokeStyle);
    }
}
