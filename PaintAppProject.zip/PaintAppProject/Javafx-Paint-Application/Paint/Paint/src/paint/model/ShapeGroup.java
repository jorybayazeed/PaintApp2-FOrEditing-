package paint.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javafx.geometry.Point2D;
import javafx.scene.canvas.Canvas;
import javafx.scene.paint.Color;

/**
 * COMPOSITE PATTERN - ShapeGroup (Composite)
 * 
 * This class allows you to treat a group of shapes as a single shape.
 * It implements the Composite design pattern.
 * 
 * Benefits:
 * 1. Group multiple shapes together
 * 2. Move/transform the entire group as one
 * 3. Draw the entire group with one command
 * 4. Can contain other groups (nested grouping)
 * 
 * Example usage:
 *   iShape circle = new Circle(start, end, color);
 *   iShape rectangle = new Rectangle(start, end, color);
 *   iShape group = new ShapeGroup();
 *   ((ShapeGroup)group).addShape(circle);
 *   ((ShapeGroup)group).addShape(rectangle);
 *   group.draw(canvas); // Draws both shapes
 */
public class ShapeGroup implements iShape {
    
    private List<iShape> shapes = new ArrayList<>();
    private Point2D groupPosition;
    private Color groupColor;
    private Color groupFillColor;
    
    public ShapeGroup() {
        this.groupPosition = new Point2D(0, 0);
        this.groupColor = Color.BLACK;
        this.groupFillColor = Color.TRANSPARENT;
    }
    
    /**
     * Add a shape to this group
     * The shape can be:
     * - A simple shape (Circle, Rectangle, etc.)
     * - A decorated shape (ShapeWithStroke, ShapeWithShadow, etc.)
     * - Another ShapeGroup (nested grouping)
     */
    public void addShape(iShape shape) {
        if (shape != null) {
            shapes.add(shape);
        }
    }
    
    /**
     * Remove a shape from this group
     */
    public void removeShape(iShape shape) {
        shapes.remove(shape);
    }
    
    /**
     * Get all shapes in this group
     */
    public List<iShape> getShapes() {
        return new ArrayList<>(shapes);
    }
    
    /**
     * Clear all shapes from this group
     */
    public void clearShapes() {
        shapes.clear();
    }
    
    /**
     * Get the number of shapes in this group
     */
    public int getShapeCount() {
        return shapes.size();
    }
    
    /**
     * Draw all shapes in the group
     */
    @Override
    public void draw(Canvas canvas) {
        // Draw all shapes in order
        for (iShape shape : shapes) {
            shape.draw(canvas);
        }
    }
    
    /**
     * Move all shapes in the group by the given position
     */
    @Override
    public void setPosition(Point2D position) {
        this.groupPosition = position;
        
        // Move all shapes relative to the group position
        // This is a simple implementation - you can make it more sophisticated
        for (iShape shape : shapes) {
            shape.setPosition(position);
        }
    }
    
    @Override
    public Point2D getPosition() {
        return groupPosition;
    }
    
    /**
     * Set color for all shapes in the group
     */
    @Override
    public void setColor(Color color) {
        this.groupColor = color;
        
        // Apply color to all shapes
        for (iShape shape : shapes) {
            shape.setColor(color);
        }
    }
    
    @Override
    public Color getColor() {
        return groupColor;
    }
    
    /**
     * Set fill color for all shapes in the group
     */
    @Override
    public void setFillColor(Color color) {
        this.groupFillColor = color;
        
        // Apply fill color to all shapes
        for (iShape shape : shapes) {
            shape.setFillColor(color);
        }
    }
    
    @Override
    public Color getFillColor() {
        return groupFillColor;
    }
    
    @Override
    public void setProperties(Map<String, Double> properties) {
        // Set properties for all shapes in group
        for (iShape shape : shapes) {
            shape.setProperties(properties);
        }
    }
    
    @Override
    public Map<String, Double> getProperties() {
        // Return properties of first shape (or could return group properties)
        if (!shapes.isEmpty()) {
            return shapes.get(0).getProperties();
        }
        return new java.util.HashMap<>();
    }
    
    @Override
    public iShape clone() throws CloneNotSupportedException {
        ShapeGroup clonedGroup = new ShapeGroup();
        
        // Clone all shapes in the group
        for (iShape shape : shapes) {
            clonedGroup.addShape((iShape) shape.clone());
        }
        
        return clonedGroup;
    }
    
    /**
     * Set the top-left position of the group
     */
    public void setTopLeft(Point2D topLeft) {
        this.groupPosition = topLeft;
        // Could also update all child shapes' positions
    }
    
    /**
     * Get the top-left position of the group
     */
    public Point2D getTopLeft() {
        return this.groupPosition != null ? this.groupPosition : new Point2D(0, 0);
    }
}
