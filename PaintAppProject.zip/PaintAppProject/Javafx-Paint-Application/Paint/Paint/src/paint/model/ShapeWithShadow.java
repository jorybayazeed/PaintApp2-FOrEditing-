package paint.model;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

/**
 * CONCRETE DECORATOR 2: ShapeWithShadow
 * 
 * This decorator adds shadow effects to any shape.
 * 
 * Usage:
 *   iShape rectangle = new Rectangle(start, end, color);
 *   iShape shadowedRectangle = new ShapeWithShadow(rectangle, 3.0);
 */
public class ShapeWithShadow extends ShapeDecorator {
    
    private double shadowOffsetX;
    private double shadowOffsetY;
    private Color shadowColor;
    
    public ShapeWithShadow(iShape shape, double shadowOffset) {
        super(shape);
        this.shadowOffsetX = shadowOffset;
        this.shadowOffsetY = shadowOffset;
        this.shadowColor = Color.color(0, 0, 0, 0.3); // Semi-transparent black
    }
    
    public ShapeWithShadow(iShape shape, double offsetX, double offsetY, Color color) {
        super(shape);
        this.shadowOffsetX = offsetX;
        this.shadowOffsetY = offsetY;
        this.shadowColor = color;
    }
    
    @Override
    public void draw(Canvas canvas) {
        GraphicsContext gc = canvas.getGraphicsContext2D();
        
        // Save original state (can be Color or Gradient)
        javafx.scene.paint.Paint originalFill = gc.getFill();
        javafx.scene.paint.Paint originalStroke = gc.getStroke();
        double originalLineWidth = gc.getLineWidth();
        
        // Draw shadow first (darker, offset version)
        gc.setFill(shadowColor);
        gc.setStroke(shadowColor);
        
        // Translate, draw shadow, then restore
        gc.save();
        gc.translate(shadowOffsetX, shadowOffsetY);
        
        // Draw the wrapped shape as shadow
        wrappedShape.draw(canvas);
        
        gc.restore();
        
        // Draw the actual shape on top (restore original colors)
        gc.setFill(originalFill);
        gc.setStroke(originalStroke);
        gc.setLineWidth(originalLineWidth);
        wrappedShape.draw(canvas);
    }
    
    public void setShadowOffset(double x, double y) {
        this.shadowOffsetX = x;
        this.shadowOffsetY = y;
    }
    
    public void setShadowColor(Color color) {
        this.shadowColor = color;
    }
    
    @Override
    public iShape clone() throws CloneNotSupportedException {
        iShape clonedInner = (wrappedShape != null) ? wrappedShape.clone() : null;
        ShapeWithShadow copy = new ShapeWithShadow(clonedInner, this.shadowOffsetX, this.shadowOffsetY, this.shadowColor);
        return (iShape) copy;
    }
}
