package paint.model;

import javafx.geometry.Point2D;
import javafx.scene.canvas.Canvas;
import javafx.scene.paint.Color;
import java.util.HashMap;
import java.util.Map;

/**
 * ADAPTER PATTERN - Wraps a decorated iShape as a Shape
 * 
 * This allows decorated shapes (which are iShape objects) to be stored
 * in the shapeList ArrayList that expects Shape objects.
 * 
 * It delegates all operations to the wrapped iShape while masquerading as a Shape.
 */
public class DecoratedShapeWrapper extends Shape {
    
    private iShape wrappedDecorated;
    private Shape baseShape;
    
    public DecoratedShapeWrapper(Shape base, iShape decorated) {
        super();
        this.baseShape = base;
        this.wrappedDecorated = decorated;
        
        // Copy base shape properties
        this.setPosition(base.getPosition());
        if (base.getEndPosition() != null) {
            this.setEndPosition(base.getEndPosition());
        }
        this.setColor(base.getColor());
        this.setFillColor(base.getFillColor());
    }
    
    @Override
    public void draw(Canvas canvas) {
        // Draw the decorated version (which includes all effects)
        wrappedDecorated.draw(canvas);
    }
    
    @Override
    public Shape clone() throws CloneNotSupportedException {
        return new DecoratedShapeWrapper(
            (Shape) baseShape.clone(),
            (iShape) wrappedDecorated.clone()
        );
    }
    
    @Override
    public void setPosition(Point2D position) {
        super.setPosition(position);
        baseShape.setPosition(position);
        wrappedDecorated.setPosition(position);
    }
    
    @Override
    public void setEndPosition(Point2D position) {
        super.setEndPosition(position);
        if (baseShape != null) {
            baseShape.setEndPosition(position);
        }
    }
    
    @Override
    public void setColor(Color color) {
        super.setColor(color);
        baseShape.setColor(color);
        wrappedDecorated.setColor(color);
    }
    
    @Override
    public void setFillColor(Color color) {
        super.setFillColor(color);
        baseShape.setFillColor(color);
        wrappedDecorated.setFillColor(color);
    }
    
    public iShape getDecoratedShape() {
        return wrappedDecorated;
    }
    
    public Shape getBaseShape() {
        return baseShape;
    }
}
