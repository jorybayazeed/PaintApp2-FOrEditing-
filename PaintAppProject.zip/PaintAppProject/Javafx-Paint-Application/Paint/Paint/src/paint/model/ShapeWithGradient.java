package paint.model;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;

/**
 * CONCRETE DECORATOR 3: ShapeWithGradient
 * 
 * This decorator adds gradient fill to any shape.
 * 
 * Usage:
 *   iShape line = new Line(start, end, color);
 *   iShape gradientLine = new ShapeWithGradient(line, Color.RED, Color.BLUE);
 */
public class ShapeWithGradient extends ShapeDecorator {
    
    private Color colorStart;
    private Color colorEnd;
    private boolean isHorizontal;
    
    public ShapeWithGradient(iShape shape, Color start, Color end) {
        super(shape);
        this.colorStart = start;
        this.colorEnd = end;
        this.isHorizontal = true;
    }
    
    public ShapeWithGradient(iShape shape, Color start, Color end, boolean horizontal) {
        super(shape);
        this.colorStart = start;
        this.colorEnd = end;
        this.isHorizontal = horizontal;
    }
    
    @Override
    public void draw(Canvas canvas) {
        GraphicsContext gc = canvas.getGraphicsContext2D();
        
        // Store original fill color
        javafx.scene.paint.Paint originalFill = gc.getFill();
        
        // Create gradient stops
        Stop[] stops = new Stop[] {
            new Stop(0, colorStart),
            new Stop(1, colorEnd)
        };
        
        // Create linear gradient
        LinearGradient gradient = new LinearGradient(
            0, 0, 
            isHorizontal ? 100 : 0, 
            isHorizontal ? 0 : 100, 
            false, 
            javafx.scene.paint.CycleMethod.NO_CYCLE, 
            stops
        );
        
        // Apply gradient fill
        gc.setFill(gradient);
        
        // Draw the wrapped shape with gradient
        wrappedShape.draw(canvas);
        
        // Restore original fill
        gc.setFill(originalFill);
    }
    
    public void setGradientColors(Color start, Color end) {
        this.colorStart = start;
        this.colorEnd = end;
    }
    
    public void setGradientDirection(boolean horizontal) {
        this.isHorizontal = horizontal;
    }
    
    @Override
    public iShape clone() throws CloneNotSupportedException {
        iShape clonedInner = (wrappedShape != null) ? wrappedShape.clone() : null;
        return (iShape) new ShapeWithGradient(clonedInner, this.colorStart, this.colorEnd, this.isHorizontal);
    }
}
