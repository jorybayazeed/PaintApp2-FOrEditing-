/**
 * ============================================================================
 * VISUAL SUMMARY: DECORATOR & COMPOSITE PATTERNS FOR PAINT APP
 * ============================================================================
 */

// ============================================================================
// PATTERN 1: DECORATOR PATTERN (For Adding Effects)
// ============================================================================

// CONCEPT:
// Wraps a shape and adds extra behavior (stroke, shadow, gradient)
// Can be layered: Gradient(Shadow(Stroke(Circle)))

// STRUCTURE:
//
//     iShape (Interface)
//        ↑
//        │ implements
//     ┌──┴──┐
//     │     │
//  Shape  ShapeDecorator (Abstract)
//  (base)      ↑
//        ┌─────┼─────┐
//        │     │     │
//   Stroke Shadow Gradient
//   (Concrete Decorators)
//
// USAGE FLOW:
//
//     Circle circle = new Circle(...);
//            ↓
//     ShapeWithStroke = new ShapeWithStroke(circle, 2.0);
//            ↓
//     ShapeWithShadow = new ShapeWithShadow(strokedCircle, 3.0);
//            ↓
//     ShapeWithGradient = new ShapeWithGradient(shadowedCircle, red, blue);
//            ↓
//     engine.addShape(gradientShadowedStrokedCircle);
//
// DRAWING PROCESS:
//
//     draw() → Gradient.draw()
//              ↓ draws with gradient, then calls wrappedShape.draw()
//              ↓ Shadow.draw()
//                ↓ draws shadow, then calls wrappedShape.draw()
//                ↓ Stroke.draw()
//                  ↓ applies stroke style, then calls wrappedShape.draw()
//                  ↓ Circle.draw()
//                    ↓ FINAL RENDERING

// ============================================================================
// PATTERN 2: COMPOSITE PATTERN (For Grouping)
// ============================================================================

// CONCEPT:
// Groups multiple shapes into one composite shape
// The group can contain other groups (nested)
// Treat group as single shape (move, color, draw all together)

// STRUCTURE:
//
//     iShape (Interface)
//        ↑
//        │ implements
//     ┌──┴──────────┐
//     │             │
//  Shape      ShapeGroup (Composite)
//  (leaf)    contains List<iShape>
//
//     Each iShape can be:
//     - Leaf shape (Circle, Rectangle, etc.)
//     - Composite (ShapeGroup)
//     - Decorated shape (ShapeWithStroke, etc.)
//
// NESTING EXAMPLE:
//
//     ShapeGroup mainGroup
//         │
//         ├─→ Circle (leaf)
//         │
//         ├─→ Rectangle (leaf)
//         │
//         └─→ ShapeGroup subGroup (composite)
//              │
//              ├─→ Line (leaf)
//              │
//              └─→ Triangle (leaf)

// ============================================================================
// COMBINING BOTH PATTERNS (THE POWER!)
// ============================================================================

// You can combine them for maximum flexibility:

//     ShapeGroup mainGroup = new ShapeGroup();
//     
//     // Add decorated shapes
//     iShape circle = new Circle(p1, p2, color);
//     circle = new ShapeWithStroke(circle, 2.0);
//     mainGroup.addShape(circle);
//     
//     // Add nested group
//     ShapeGroup subGroup = new ShapeGroup();
//     subGroup.addShape(new Rectangle(...));
//     subGroup.addShape(new Line(...));
//     mainGroup.addShape(subGroup);
//     
//     // Decorate the entire group!
//     iShape finalShape = new ShapeWithShadow(mainGroup, 3.0);
//     
//     engine.addShape(finalShape);

// ============================================================================
// FILES TO CREATE (5 NEW CLASSES)
// ============================================================================

/*
 * 1. ShapeDecorator.java (Abstract Base)
 *    ├─ Purpose: Abstract base for all decorators
 *    ├─ Location: src/paint/model/
 *    ├─ Implements: iShape
 *    └─ Key: wrappedShape field + delegation
 *
 * 2. ShapeWithStroke.java (Concrete Decorator)
 *    ├─ Purpose: Add stroke styling
 *    ├─ Location: src/paint/model/
 *    ├─ Extends: ShapeDecorator
 *    └─ Adds: strokeWidth, strokeStyle
 *
 * 3. ShapeWithShadow.java (Concrete Decorator)
 *    ├─ Purpose: Add shadow effects
 *    ├─ Location: src/paint/model/
 *    ├─ Extends: ShapeDecorator
 *    └─ Adds: shadowOffset, shadowColor
 *
 * 4. ShapeWithGradient.java (Concrete Decorator)
 *    ├─ Purpose: Add gradient fill
 *    ├─ Location: src/paint/model/
 *    ├─ Extends: ShapeDecorator
 *    └─ Adds: colorStart, colorEnd
 *
 * 5. ShapeGroup.java (Composite)
 *    ├─ Purpose: Group multiple shapes
 *    ├─ Location: src/paint/model/
 *    ├─ Implements: iShape
 *    └─ Key: List<iShape> shapes
 */

// ============================================================================
// FILES TO MODIFY (2 EXISTING FILES)
// ============================================================================

/*
 * 1. FXMLDocumentController.java
 *    ├─ ADD: Imports for new classes
 *    ├─ ADD: @FXML fields for UI controls
 *    ├─ MODIFY: onMouseReleased() method to apply decorators
 *    └─ ADD: groupShapes() method for composite
 *
 * 2. FXMLDocument.fxml
 *    ├─ ADD: CheckBox for stroke option
 *    ├─ ADD: TextField for stroke width
 *    ├─ ADD: ComboBox for stroke style
 *    ├─ ADD: CheckBox for shadow option
 *    ├─ ADD: TextField for shadow offset
 *    ├─ ADD: CheckBox for gradient option
 *    └─ ADD: ColorPickers for gradient colors
 */

// ============================================================================
// FILES TO KEEP UNCHANGED (Do NOT modify)
// ============================================================================

/*
 * - Shape.java
 * - Circle.java
 * - Rectangle.java
 * - Line.java
 * - Triangle.java
 * - iShape.java
 * - ShapeFactory.java
 * - DrawingEngine.java
 *
 * This is the power of the pattern: add features WITHOUT modifying existing!
 */

// ============================================================================
// KEY EDITING LOCATIONS
// ============================================================================

/*
 * ┌─────────────────────────────────────────────────────────────────────────┐
 * │ FILE: FXMLDocumentController.java                                       │
 * ├─────────────────────────────────────────────────────────────────────────┤
 * │                                                                          │
 * │ LOCATION 1: Top imports section                                         │
 * │ ───────────                                                             │
 * │ ADD: import paint.model.ShapeWithStroke;                                │
 * │ ADD: import paint.model.ShapeWithShadow;                                │
 * │ ADD: import paint.model.ShapeWithGradient;                              │
 * │ ADD: import paint.model.ShapeGroup;                                     │
 * │                                                                          │
 * │ LOCATION 2: Class fields (with other @FXML fields)                     │
 * │ ───────────                                                             │
 * │ ADD: @FXML CheckBox strokeCheckbox;                                     │
 * │ ADD: @FXML TextField strokeWidthTextField;                              │
 * │ ADD: @FXML ComboBox<String> strokeStyleComboBox;                        │
 * │ ADD: @FXML CheckBox shadowCheckbox;                                     │
 * │ ADD: @FXML TextField shadowOffsetTextField;                             │
 * │ ADD: @FXML CheckBox gradientCheckbox;                                   │
 * │ ADD: @FXML ColorPicker gradientStartColorPicker;                        │
 * │ ADD: @FXML ColorPicker gradientEndColorPicker;                          │
 * │                                                                          │
 * │ LOCATION 3: onMouseReleased() or mouse event handler                   │
 * │ ───────────                                                             │
 * │ REPLACE: The shape creation section with decorator logic                │
 * │                                                                          │
 * │ BEFORE:                                                                 │
 * │   iShape shape = ShapeFactory.createShape(...);                         │
 * │   engine.addShape(shape);                                               │
 * │                                                                          │
 * │ AFTER:                                                                  │
 * │   iShape shape = ShapeFactory.createShape(...);                         │
 * │   if (strokeCheckbox.isSelected()) {                                    │
 * │       shape = new ShapeWithStroke(shape, width, style);                 │
 * │   }                                                                      │
 * │   if (shadowCheckbox.isSelected()) {                                    │
 * │       shape = new ShapeWithShadow(shape, offset);                       │
 * │   }                                                                      │
 * │   if (gradientCheckbox.isSelected()) {                                  │
 * │       shape = new ShapeWithGradient(shape, color1, color2);             │
 * │   }                                                                      │
 * │   engine.addShape(shape);                                               │
 * │                                                                          │
 * └─────────────────────────────────────────────────────────────────────────┘
 */

/*
 * ┌─────────────────────────────────────────────────────────────────────────┐
 * │ FILE: FXMLDocument.fxml                                                 │
 * ├─────────────────────────────────────────────────────────────────────────┤
 * │                                                                          │
 * │ LOCATION: Somewhere in your layout (e.g., in a VBox with other controls)│
 * │                                                                          │
 * │ ADD: UI control elements for decorator options                          │
 * │      (See DECORATOR_AND_COMPOSITE_GUIDE.md for exact XML)               │
 * │                                                                          │
 * │ KEY ELEMENTS:                                                           │
 * │ - CheckBox fx:id="strokeCheckbox"                                       │
 * │ - TextField fx:id="strokeWidthTextField"                                │
 * │ - ComboBox fx:id="strokeStyleComboBox"                                  │
 * │ - CheckBox fx:id="shadowCheckbox"                                       │
 * │ - TextField fx:id="shadowOffsetTextField"                               │
 * │ - CheckBox fx:id="gradientCheckbox"                                     │
 * │ - ColorPicker fx:id="gradientStartColorPicker"                          │
 * │ - ColorPicker fx:id="gradientEndColorPicker"                            │
 * │                                                                          │
 * └─────────────────────────────────────────────────────────────────────────┘
 */

// ============================================================================
// EXECUTION SEQUENCE (When user draws a shape)
// ============================================================================

/*
 * 1. User selects shape type (circle, rectangle, etc.)
 * 2. User selects options (stroke, shadow, gradient checkboxes)
 * 3. User draws shape with mouse
 * 4. onMouseReleased() called:
 *
 *    a) Base shape created: iShape shape = ShapeFactory.createShape(...)
 *    
 *    b) IF stroke checkbox selected:
 *       → shape = new ShapeWithStroke(shape, width, style)
 *       → shape is now WRAPPED
 *    
 *    c) IF shadow checkbox selected:
 *       → shape = new ShapeWithShadow(shape, offset)
 *       → shape is now WRAPPED AGAIN
 *    
 *    d) IF gradient checkbox selected:
 *       → shape = new ShapeWithGradient(shape, color1, color2)
 *       → shape is now WRAPPED AGAIN
 *    
 *    e) engine.addShape(shape) - adds the (possibly decorated) shape
 *    
 *    f) redrawCanvas() - calls draw() on all shapes
 *    
 *    g) Draw process:
 *       → If decorated: outermost decorator's draw() called
 *       → Each decorator calls wrappedShape.draw()
 *       → Finally reaches the base shape's draw()
 *       → All rendering applied in correct order
 * 
 * 5. Result: Shape displayed with selected effects
 */

// ============================================================================
// EXAMPLE: Complete decoration sequence
// ============================================================================

/*
 * User actions:
 * 1. Selects "Circle" shape type
 * 2. Checks "Add Stroke"
 * 3. Checks "Add Shadow"
 * 4. Checks "Use Gradient"
 * 5. Draws on canvas
 *
 * Code execution:
 *
 *     iShape shape = new Circle(p1, p2, RED);           // Base shape
 *     
 *     shape = new ShapeWithStroke(shape, 2.0, "solid"); // Wrap 1
 *     // shape is now:
 *     // ShapeWithStroke {
 *     //     wrappedShape = Circle { }
 *     // }
 *     
 *     shape = new ShapeWithShadow(shape, 3.0);          // Wrap 2
 *     // shape is now:
 *     // ShapeWithShadow {
 *     //     wrappedShape = ShapeWithStroke {
 *     //         wrappedShape = Circle { }
 *     //     }
 *     // }
 *     
 *     shape = new ShapeWithGradient(shape, RED, BLUE);  // Wrap 3
 *     // shape is now:
 *     // ShapeWithGradient {
 *     //     wrappedShape = ShapeWithShadow {
 *     //         wrappedShape = ShapeWithStroke {
 *     //             wrappedShape = Circle { }
 *     //         }
 *     //     }
 *     // }
 *     
 *     engine.addShape(shape);
 *
 * When drawn, GradientCircle → Shadow → Stroke → Circle rendering occurs!
 */

// ============================================================================
// END OF VISUAL SUMMARY
// ============================================================================
