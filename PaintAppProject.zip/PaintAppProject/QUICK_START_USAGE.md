# QUICK START: USING DECORATOR & COMPOSITE

## 🚀 3-MINUTE UNDERSTANDING

### **What is Decorator?**
Decorator wraps a shape and adds effects to it.

```
Before: Circle (RED)
After:  Decorated(Decorated(Decorated(Circle))) 
        = Circle (RED) + Stroke + Shadow + Gradient
```

### **What is Composite?**
Composite groups multiple shapes into one.

```
Before: [Circle, Rectangle, Line] (3 separate shapes)
After:  ShapeGroup {Circle, Rectangle, Line} (1 group)
```

---

## 💻 COPY-PASTE CODE EXAMPLES

### **Example 1: Use Decorator - Add Stroke**

**File:** `FXMLDocumentController.java` (In onMouseReleased method)

**Add this after shape creation:**
```java
Shape sh = new ShapeFactory().createShape(type, start, end, ColorBox.getValue());

// ✨ DECORATE: Add stroke
iShape styledShape = new ShapeWithStroke((iShape) sh, 2.0, "solid");

addShape((Shape) styledShape);
styledShape.draw(CanvasBox);
```

### **Example 2: Use Decorator - Stack Multiple Effects**

```java
// Create base shape
iShape shape = (iShape) new ShapeFactory().createShape(type, start, end, ColorBox.getValue());

// Layer 1: Add stroke
shape = new ShapeWithStroke(shape, 2.0, "dashed");

// Layer 2: Add shadow on top of stroke
shape = new ShapeWithShadow(shape, 4.0);

// Layer 3: Add gradient on top of shadow
shape = new ShapeWithGradient(shape, Color.RED, Color.BLUE);

// Result: Shape now has stroke + shadow + gradient!
addShape((Shape) shape);
shape.draw(CanvasBox);
```

### **Example 3: Use Decorator - With UI Controls**

**Add to FXML first:**
```xml
<CheckBox fx:id="enableStroke" text="Stroke" />
<CheckBox fx:id="enableShadow" text="Shadow" />
<CheckBox fx:id="enableGradient" text="Gradient" />
```

**Add to Controller:**
```java
@FXML
private CheckBox enableStroke;
@FXML
private CheckBox enableShadow;
@FXML
private CheckBox enableGradient;

// In onMouseReleased():
Shape sh = new ShapeFactory().createShape(type, start, end, ColorBox.getValue());
iShape decoratedShape = (iShape) sh;

if (enableStroke.isSelected()) {
    decoratedShape = new ShapeWithStroke(decoratedShape, 2.0, "solid");
}

if (enableShadow.isSelected()) {
    decoratedShape = new ShapeWithShadow(decoratedShape, 3.0);
}

if (enableGradient.isSelected()) {
    decoratedShape = new ShapeWithGradient(decoratedShape, Color.BLUE, Color.GREEN);
}

addShape((Shape) decoratedShape);
decoratedShape.draw(CanvasBox);
```

### **Example 4: Use Composite - Create a Group**

```java
// Create individual shapes
iShape circle = new Circle(p1, p2, Color.RED);
iShape rect = new Rectangle(p3, p4, Color.BLUE);

// Group them
ShapeGroup group = new ShapeGroup();
group.addShape(circle);
group.addShape(rect);

// Use the group as a single shape
addShape((Shape) group);
group.draw(CanvasBox);

// Move ALL shapes at once:
group.setPosition(new Point2D(100, 100));

// Color ALL shapes at once:
group.setColor(Color.GREEN);
```

### **Example 5: Use Composite - From UI (Group Selected Shapes)**

**Add button to FXML:**
```xml
<Button fx:id="groupBtn" text="Group Selected" onAction="#handleGroup" />
```

**Add method to Controller:**
```java
@FXML
private void handleGroup(ActionEvent event) {
    ObservableList<Integer> selected = ShapeList.getSelectionModel().getSelectedIndices();
    
    if (selected.size() < 2) {
        Message.setText("Select at least 2 shapes to group!");
        return;
    }
    
    // Create composite group
    ShapeGroup group = new ShapeGroup();
    
    // Add selected shapes to group
    List<Integer> toRemove = new ArrayList<>();
    for (Integer idx : selected) {
        group.addShape(shapeList.get(idx));
        toRemove.add(idx);
    }
    
    // Remove from original list (in reverse order to maintain indices)
    for (int i = toRemove.size() - 1; i >= 0; i--) {
        shapeList.remove((int) toRemove.get(i));
    }
    
    // Add group as new shape
    shapeList.add((Shape) group);
    
    Message.setText("Grouped " + selected.size() + " shapes!");
    redraw();
}
```

### **Example 6: Advanced - Decorate a Group**

```java
// Create group
ShapeGroup group = new ShapeGroup();
group.addShape(circle);
group.addShape(rectangle);

// Decorate the ENTIRE GROUP
iShape decoratedGroup = new ShapeWithStroke((iShape) group, 3.0, "dashed");
decoratedGroup = new ShapeWithShadow(decoratedGroup, 2.0);

// Result: All shapes in group have stroke and shadow!
addShape((Shape) decoratedGroup);
decoratedGroup.draw(CanvasBox);
```

---

## 📋 STEP-BY-STEP IMPLEMENTATION

### **Step 1: Locate onMouseReleased Method**

**File:** `src/paint/controller/FXMLDocumentController.java`

**Find (Line ~280):**
```java
public void onMouseReleased(MouseEvent event) {
    // ... code ...
    sh = new ShapeFactory().createShape(type,start,end,ColorBox.getValue());
    addShape(sh);
    sh.draw(CanvasBox);
}
```

### **Step 2: Add Decorator Support**

**Replace those 3 lines with:**
```java
Shape sh = new ShapeFactory().createShape(type, start, end, ColorBox.getValue());

// Convert to iShape for decorator support
iShape decoratedShape = (iShape) sh;

// Optionally apply decorators here (add if-statements for UI controls)
// Example:
// if (someCondition) {
//     decoratedShape = new ShapeWithStroke(decoratedShape, 2.0, "solid");
// }

addShape((Shape) decoratedShape);
decoratedShape.draw(CanvasBox);
```

### **Step 3: Add UI Controls (Optional but Recommended)**

**Edit FXML file** (`src/paint/view/FXMLDocument.fxml`):
```xml
<!-- Add these controls to your UI -->
<CheckBox fx:id="strokeCheckbox" text="Add Stroke" />
<CheckBox fx:id="shadowCheckbox" text="Add Shadow" />
<CheckBox fx:id="gradientCheckbox" text="Add Gradient" />
<Button fx:id="groupButton" text="Group Selected" onAction="#handleGroupAction" />
```

### **Step 4: Add Controller Fields**

**Add to FXMLDocumentController:**
```java
@FXML
private CheckBox strokeCheckbox;

@FXML
private CheckBox shadowCheckbox;

@FXML
private CheckBox gradientCheckbox;

@FXML
private Button groupButton;
```

### **Step 5: Update onMouseReleased**

```java
private void onMouseReleased(MouseEvent event) {
    String type = ShapeBox.getValue();
    Point2D start = new Point2D(startX, startY);
    Point2D end = new Point2D(event.getX(), event.getY());
    
    Shape sh = new ShapeFactory().createShape(type, start, end, ColorBox.getValue());
    
    // ✨ APPLY DECORATORS BASED ON CHECKBOXES
    iShape decoratedShape = (iShape) sh;
    
    if (strokeCheckbox.isSelected()) {
        decoratedShape = new ShapeWithStroke(decoratedShape, 2.0, "solid");
    }
    
    if (shadowCheckbox.isSelected()) {
        decoratedShape = new ShapeWithShadow(decoratedShape, 3.0);
    }
    
    if (gradientCheckbox.isSelected()) {
        decoratedShape = new ShapeWithGradient(
            decoratedShape, 
            Color.color(Math.random(), Math.random(), Math.random()),
            Color.color(Math.random(), Math.random(), Math.random())
        );
    }
    
    addShape((Shape) decoratedShape);
    decoratedShape.draw(CanvasBox);
}
```

### **Step 6: Add Group Handler**

```java
@FXML
private void handleGroupAction(ActionEvent event) {
    ObservableList<Integer> selected = ShapeList.getSelectionModel().getSelectedIndices();
    
    if (selected.size() < 2) {
        Message.setText("Select at least 2 shapes to group!");
        return;
    }
    
    ShapeGroup group = new ShapeGroup();
    
    for (Integer idx : selected) {
        group.addShape(shapeList.get(idx));
    }
    
    for (int i = selected.size() - 1; i >= 0; i--) {
        shapeList.remove((int) selected.get(i));
    }
    
    shapeList.add((Shape) group);
    Message.setText("Created group with " + selected.size() + " shapes!");
    
    // Refresh display
    refreshShapeList();
    redraw();
}
```

### **Step 7: Compile**

```powershell
cd "C:\Users\goryg\OneDrive\سطح المكتب\PaintAppProject\Javafx-Paint-Application\Paint\Paint"
& "C:\Users\goryg\OneDrive\سطح المكتب\JavaJDK\openJdk-25\bin\javac.exe" -d build/classes --module-path "C:\Users\goryg\OneDrive\سطح المكتب\javafx-sdk-21.0.3\lib" --add-modules javafx.controls,javafx.fxml -sourcepath src src\paint\Paint.java src\paint\model\*.java src\paint\controller\*.java
```

### **Step 8: Run**

```powershell
& "C:\Users\goryg\OneDrive\سطح المكتب\JavaJDK\openJdk-25\bin\java.exe" --enable-native-access=javafx.graphics --module-path "C:\Users\goryg\OneDrive\سطح المكتب\javafx-sdk-21.0.3\lib" --add-modules javafx.controls,javafx.fxml -cp build/classes paint.Paint
```

---

## ✅ TESTING CHECKLIST

- [ ] Draw a shape
- [ ] Check "Add Stroke" checkbox
- [ ] Draw another shape → should have stroke
- [ ] Check "Add Shadow" checkbox
- [ ] Draw another shape → should have stroke + shadow
- [ ] Check "Add Gradient" checkbox
- [ ] Draw another shape → should have all 3 effects
- [ ] Draw 2-3 shapes without effects
- [ ] Select all 3 shapes in the list
- [ ] Click "Group Selected" button
- [ ] Verify they're grouped as single item
- [ ] Try to move/color the group → all shapes move/color together

---

## 🎓 WHAT YOU LEARNED

✅ **Decorator Pattern** - Add effects dynamically without modifying original classes
✅ **Composite Pattern** - Group shapes and treat group as single shape
✅ **Combination** - Decorate entire groups with effects
✅ **UI Integration** - Connect patterns to UI controls

---

## 🚀 NEXT ADVANCED FEATURES

1. **Ungroup button** - Decompose a group back into individual shapes
2. **Save/Load** - Persist decorated shapes and groups to XML
3. **Copy/Paste** - Clone decorated shapes with all effects
4. **Undo/Redo** - Implement with command pattern

Enjoy! 🎉
