# 📚 DECORATOR & COMPOSITE - VISUAL REFERENCE CARD

## 🎨 DECORATOR PATTERN - AT A GLANCE

### **What is it?**
Wraps a shape to add effects **without changing the shape class**.

### **When to use it?**
- Add stroke, shadow, or gradient to ANY shape
- Stack multiple effects
- Apply effects at runtime

### **Class Hierarchy:**
```
iShape (interface)
  ↑
  ├─ Shape (abstract) → Circle, Rectangle, Line, etc.
  │
  └─ ShapeDecorator (abstract)
      ├─ ShapeWithStroke
      ├─ ShapeWithShadow
      └─ ShapeWithGradient
```

### **Core Concept:**
```java
// Before: Circle with RED color only
Circle circle = new Circle(p1, p2, Color.RED);

// After: Same circle wrapped with effects
iShape decorated = new ShapeWithStroke(circle, 2.0);
decorated = new ShapeWithShadow(decorated, 3.0);
decorated = new ShapeWithGradient(decorated, Color.RED, Color.BLUE);
// Now it has: RED color + STROKE + SHADOW + GRADIENT!
```

### **Key Methods:**
```java
ShapeWithStroke.draw()      // Applies stroke + calls wrapped.draw()
ShapeWithShadow.draw()      // Applies shadow + calls wrapped.draw()
ShapeWithGradient.draw()    // Applies gradient + calls wrapped.draw()
```

### **Decorator Classes Location:**
```
src/paint/model/
├── ShapeDecorator.java        ← Abstract base
├── ShapeWithStroke.java       ← Concrete #1 (adds stroke)
├── ShapeWithShadow.java       ← Concrete #2 (adds shadow)
└── ShapeWithGradient.java     ← Concrete #3 (adds gradient)
```

---

## 🔗 COMPOSITE PATTERN - AT A GLANCE

### **What is it?**
Groups multiple shapes into **ONE logical unit**.

### **When to use it?**
- Group shapes together
- Move/resize/color multiple shapes as one
- Treat group like a single shape

### **Class Hierarchy:**
```
iShape (interface)
  ↑
  ├─ Shape (abstract)           → Circle, Rectangle, Line, etc.
  ├─ ShapeDecorator (abstract)  → ShapeWithStroke, etc.
  │
  └─ ShapeGroup (implements iShape)
     └── contains: List<iShape>
```

### **Core Concept:**
```java
// Before: 3 separate shapes
Circle circle = new Circle(p1, p2, Color.RED);
Rectangle rect = new Rectangle(p3, p4, Color.BLUE);
Line line = new Line(p5, p6, Color.GREEN);

// After: Grouped as one
ShapeGroup group = new ShapeGroup();
group.addShape(circle);
group.addShape(rect);
group.addShape(line);

// Now treat as single shape:
group.setPosition(newPos);  // Moves all 3
group.setColor(newColor);   // Colors all 3
group.draw(canvas);         // Draws all 3
```

### **Key Methods:**
```java
ShapeGroup.addShape(iShape)       // Add shape to group
ShapeGroup.removeShape(iShape)     // Remove from group
ShapeGroup.draw(Canvas)            // Draw all shapes
ShapeGroup.setPosition(Point2D)    // Move all shapes
ShapeGroup.setColor(Color)         // Color all shapes
```

### **Composite Class Location:**
```
src/paint/model/
└── ShapeGroup.java  ← Contains List<iShape>
```

---

## 🔄 COMBINING DECORATOR + COMPOSITE

### **Pattern:**
```
Composite (ShapeGroup)
    ↓
Decorator (ShapeWithStroke)
    ↓
Decorator (ShapeWithShadow)
    ↓
Shapes (Circle, Rectangle, Line)
```

### **Code Example:**
```java
// Create group with shapes
ShapeGroup group = new ShapeGroup();
group.addShape(new Circle(...));
group.addShape(new Rectangle(...));

// Decorate the GROUP
iShape styled = new ShapeWithStroke((iShape) group, 2.0);
styled = new ShapeWithShadow(styled, 3.0);

// Result: ALL shapes in group have stroke + shadow!
styled.draw(canvas);
```

---

## 📍 WHERE PATTERNS ARE USED

### **Location 1: Model Layer** (Creating patterns)
```
src/paint/model/
├── ShapeDecorator.java         ← Defines decorator interface
├── ShapeWithStroke.java        ← Implements decorator
├── ShapeWithShadow.java        ← Implements decorator
├── ShapeWithGradient.java      ← Implements decorator
└── ShapeGroup.java             ← Implements composite
```

### **Location 2: Controller Layer** (Using patterns)
```
src/paint/controller/FXMLDocumentController.java

Line ~280: onMouseReleased(MouseEvent event)
    ├── Factory creates base shape
    ├── ✨ Decorator wraps shape with effects
    ├── 🔗 Composite groups shapes
    └── Draw on canvas
```

---

## 💻 USAGE PATTERN SUMMARY

### **DECORATOR USAGE PATTERN:**
```java
// Step 1: Create base shape
iShape shape = (iShape) new ShapeFactory().createShape(...);

// Step 2: Wrap with decorators
shape = new ShapeWithStroke(shape, 2.0, "solid");
shape = new ShapeWithShadow(shape, 3.0);
shape = new ShapeWithGradient(shape, Color.RED, Color.BLUE);

// Step 3: Draw (effects applied automatically)
shape.draw(canvas);
```

### **COMPOSITE USAGE PATTERN:**
```java
// Step 1: Create group
ShapeGroup group = new ShapeGroup();

// Step 2: Add shapes to group
group.addShape(shape1);
group.addShape(shape2);
group.addShape(shape3);

// Step 3: Use group like single shape
group.setPosition(point);
group.setColor(color);
group.draw(canvas);
```

### **COMBINED USAGE PATTERN:**
```java
// Create shapes
iShape s1 = new Circle(...);
iShape s2 = new Rectangle(...);

// Group them
ShapeGroup group = new ShapeGroup();
group.addShape(s1);
group.addShape(s2);

// Decorate the group
iShape decorated = new ShapeWithStroke((iShape) group, 2.0);
decorated = new ShapeWithShadow(decorated, 3.0);

// Result: Grouped + decorated
decorated.draw(canvas);
```

---

## 🎯 QUICK DECISION TABLE

| Want to... | Use Pattern | Code |
|-----------|------------|------|
| Add stroke to shape | Decorator | `new ShapeWithStroke(shape, 2.0)` |
| Add shadow to shape | Decorator | `new ShapeWithShadow(shape, 3.0)` |
| Add gradient to shape | Decorator | `new ShapeWithGradient(shape, c1, c2)` |
| Stack multiple effects | Decorator | Chain them: `d1 = new With...(d0)` |
| Group shapes | Composite | `group.addShape(shape)` |
| Move all grouped shapes | Composite | `group.setPosition(point)` |
| Color all grouped shapes | Composite | `group.setColor(color)` |
| Decorate a group | Both | Wrap group with decorators |

---

## 🔍 KEY DIFFERENCES

### **Decorator:**
- ✅ Enhances single shape with features
- ✅ Stackable (chain decorators)
- ✅ Runtime effects
- ❌ Doesn't combine shapes

### **Composite:**
- ✅ Combines multiple shapes
- ✅ Treats group as single shape
- ✅ Operations on all children
- ❌ Doesn't add visual effects

### **Both Together:**
- ✅ Combine shapes (Composite)
- ✅ Add effects to combined shapes (Decorator)
- ✅ Maximum flexibility

---

## 🧠 MENTAL MODEL

### **Think of Decorator like:**
```
Wrapping paper → wraps around box
    │
    ├─ First wrap: RED paper (ColorPicker)
    ├─ Second wrap: GOLD ribbon (Stroke)
    └─ Third wrap: BOW (Shadow)
    
Result: DECORATED BOX with all wrappings
```

### **Think of Composite like:**
```
Folder → contains files
    │
    ├─ file1.txt
    ├─ file2.txt
    └─ file3.txt
    
Result: FOLDER as single unit (move, copy, delete folder)
```

---

## 📋 CHECKLIST: WHEN TO USE

### **Use DECORATOR when:**
- [ ] Want to add visual effects to a shape
- [ ] Effects are optional/toggleable
- [ ] Want to combine multiple effects
- [ ] Don't want to modify Shape classes
- [ ] Effects apply at draw time

### **Use COMPOSITE when:**
- [ ] Need to group multiple shapes
- [ ] Want to treat group as single unit
- [ ] Need to move/color all shapes together
- [ ] Want hierarchical structure
- [ ] Need to iterate over children

### **Use BOTH when:**
- [ ] Want grouped shapes with effects
- [ ] Need maximum flexibility
- [ ] Group should have visual decorations

---

## 🎓 EXAMPLE OUTPUT

### **Decorator Only:**
```
╔════════════════╗
║    CIRCLE      │  ← Shape
║   (with stroke)│  ← Decorator 1
║   (with shadow)│  ← Decorator 2
║  (with gradient)  ← Decorator 3
╚════════════════╝
```

### **Composite Only:**
```
ShapeGroup {
    ├─ Circle ─────┐
    ├─ Rectangle ──┼─ All move together
    └─ Line ───────┘
}
```

### **Both Combined:**
```
╔════════════════════════════════════╗
║  ShapeGroup (with effects)         │
║  ├─ Circle ────────────────────┐   │
║  ├─ Rectangle ─────────────────┼───┤ All shapes
║  └─ Line ──────────────────────┘   │ get all
║                                    │ decorations
║  Effects: Stroke + Shadow + Gradient
╚════════════════════════════════════╝
```

---

## 🚀 QUICK REFERENCE COMMANDS

### **Compile:**
```powershell
javac -d build/classes --module-path javafx-sdk/lib --add-modules javafx.controls,javafx.fxml -sourcepath src src/**/*.java
```

### **Run:**
```powershell
java --enable-native-access=javafx.graphics --module-path javafx-sdk/lib --add-modules javafx.controls,javafx.fxml -cp build/classes paint.Paint
```

---

**Print this page and keep it on your desk while coding! 📌**
