# Paint App - Decorator & Composite Pattern Implementation Guide

## 📁 Files Created

### 1. **ShapeDecorator.java** (Abstract Decorator Base)
```
Location: src/paint/model/ShapeDecorator.java

Purpose: 
  - Base class for all decorators
  - Implements iShape interface
  - Wraps another iShape (composition)
  - Delegates methods to wrapped shape by default

Key Methods:
  - ShapeDecorator(iShape shape)  // Constructor - wraps the shape
  - draw(Canvas canvas)            // Override to add effects
  - All other methods delegate to wrappedShape
```

---

### 2. **ShapeWithStroke.java** (Concrete Decorator)
```
Location: src/paint/model/ShapeWithStroke.java

Purpose: Adds stroke styling to any shape

Features:
  - Stroke width control (thin, medium, thick)
  - Stroke style ("solid", "dashed", "dotted")
  - Modifies GraphicsContext before drawing

Constructor:
  new ShapeWithStroke(iShape shape, double width)
  new ShapeWithStroke(iShape shape, double width, String style)
```

---

### 3. **ShapeWithShadow.java** (Concrete Decorator)
```
Location: src/paint/model/ShapeWithShadow.java

Purpose: Adds shadow/glow effects to any shape

Features:
  - Shadow offset (X, Y)
  - Shadow color customization
  - Customizable blur

Constructor:
  new ShapeWithShadow(iShape shape, double offset)
  new ShapeWithShadow(iShape shape, double offsetX, double offsetY, Color color)
```

---

### 4. **ShapeWithGradient.java** (Concrete Decorator)
```
Location: src/paint/model/ShapeWithGradient.java

Purpose: Adds gradient fill to any shape

Features:
  - Gradient start color
  - Gradient end color
  - Horizontal or vertical direction

Constructor:
  new ShapeWithGradient(iShape shape, Color start, Color end)
  new ShapeWithGradient(iShape shape, Color start, Color end, boolean horizontal)
```

---

### 5. **ShapeGroup.java** (Composite)
```
Location: src/paint/model/ShapeGroup.java

Purpose: Groups multiple shapes together

Features:
  - Add/remove shapes to group
  - Move entire group as one
  - Apply color/properties to all shapes
  - Draw all shapes in one call
  - Support nested groups!

Methods:
  - addShape(iShape shape)
  - removeShape(iShape shape)
  - getShapes() : List<iShape>
  - clearShapes()
  - draw(Canvas canvas) // Draws all shapes
```

---

## 🎯 WHERE TO EDIT - Your Existing Files

### EDIT LOCATION #1: FXMLDocumentController.java

#### Change 1: Add Imports (Top of file)
```java
// Already have:
import paint.model.*;

// Add these:
import paint.model.ShapeWithStroke;
import paint.model.ShapeWithShadow;
import paint.model.ShapeWithGradient;
import paint.model.ShapeGroup;
```

#### Change 2: Add FXML Fields
```java
@FXML
private CheckBox strokeCheckbox;

@FXML
private TextField strokeWidthTextField;

@FXML
private ComboBox<String> strokeStyleComboBox;

@FXML
private CheckBox shadowCheckbox;

@FXML
private TextField shadowOffsetTextField;

@FXML
private CheckBox gradientCheckbox;

@FXML
private ColorPicker gradientStartColorPicker;

@FXML
private ColorPicker gradientEndColorPicker;
```

#### Change 3: Modify Mouse Event Handler
**FIND** this existing code:
```java
@FXML
private void onMouseReleased(MouseEvent event) {
    Point2D end = new Point2D(event.getX(), event.getY());
    Color color = colorPicker.getValue();
    
    iShape shape = ShapeFactory.createShape(shapeType, startPoint, end, color);
    engine.addShape(shape);
    
    redrawCanvas();
}
```

**REPLACE WITH**:
```java
@FXML
private void onMouseReleased(MouseEvent event) {
    Point2D end = new Point2D(event.getX(), event.getY());
    Color color = colorPicker.getValue();
    
    // Create base shape
    iShape shape = ShapeFactory.createShape(shapeType, startPoint, end, color);
    
    // DECORATOR PATTERN: Apply effects
    
    // Add stroke if selected
    if (strokeCheckbox.isSelected()) {
        double width = Double.parseDouble(strokeWidthTextField.getText());
        String style = strokeStyleComboBox.getValue();
        shape = new ShapeWithStroke(shape, width, style);
    }
    
    // Add shadow if selected
    if (shadowCheckbox.isSelected()) {
        double offset = Double.parseDouble(shadowOffsetTextField.getText());
        shape = new ShapeWithShadow(shape, offset);
    }
    
    // Add gradient if selected
    if (gradientCheckbox.isSelected()) {
        Color start = gradientStartColorPicker.getValue();
        Color end = gradientEndColorPicker.getValue();
        shape = new ShapeWithGradient(shape, start, end);
    }
    
    engine.addShape(shape);
    redrawCanvas();
}
```

---

### EDIT LOCATION #2: FXMLDocument.fxml

**ADD** these UI controls to your FXML layout:

```xml
<!-- Stroke Section -->
<VBox spacing="5">
    <CheckBox fx:id="strokeCheckbox" text="Add Stroke Style"/>
    <HBox spacing="5">
        <Label text="Width:"/>
        <TextField fx:id="strokeWidthTextField" text="2.0" prefWidth="60"/>
        <Label text="Style:"/>
        <ComboBox fx:id="strokeStyleComboBox" prefWidth="100">
            <items>
                <FXCollections fx:factory="observableArrayList">
                    <String fx:value="solid"/>
                    <String fx:value="dashed"/>
                    <String fx:value="dotted"/>
                </FXCollections>
            </items>
        </ComboBox>
    </HBox>
</VBox>

<!-- Shadow Section -->
<VBox spacing="5">
    <CheckBox fx:id="shadowCheckbox" text="Add Shadow Effect"/>
    <HBox spacing="5">
        <Label text="Offset:"/>
        <TextField fx:id="shadowOffsetTextField" text="3.0" prefWidth="60"/>
    </HBox>
</VBox>

<!-- Gradient Section -->
<VBox spacing="5">
    <CheckBox fx:id="gradientCheckbox" text="Use Gradient Fill"/>
    <HBox spacing="5">
        <Label text="Start Color:"/>
        <ColorPicker fx:id="gradientStartColorPicker" value="#FF0000"/>
        <Label text="End Color:"/>
        <ColorPicker fx:id="gradientEndColorPicker" value="#0000FF"/>
    </HBox>
</VBox>
```

---

## 📊 Usage Examples

### Example 1: Simple Stroke Decoration
```java
iShape circle = new Circle(start, end, Color.BLUE);
iShape styledCircle = new ShapeWithStroke(circle, 3.0, "dashed");
engine.addShape(styledCircle);
```

### Example 2: Stacking Multiple Decorators
```java
iShape rect = new Rectangle(start, end, Color.GREEN);

// Add stroke
rect = new ShapeWithStroke(rect, 2.0);

// Add shadow on top of stroke
rect = new ShapeWithShadow(rect, 4.0);

// Add gradient on top of shadow
rect = new ShapeWithGradient(rect, Color.RED, Color.BLUE);

engine.addShape(rect);
```

### Example 3: Grouping Shapes
```java
iShape circle = new Circle(p1, p2, Color.RED);
iShape line = new Line(p1, p2, Color.BLACK);

ShapeGroup group = new ShapeGroup();
group.addShape(circle);
group.addShape(line);

engine.addShape(group);

// Move entire group by setting position
group.setPosition(new Point2D(100, 100));
```

### Example 4: Group with Decorators
```java
ShapeGroup group = new ShapeGroup();
group.addShape(circle);
group.addShape(rectangle);

// Apply decorator to entire group!
iShape styledGroup = new ShapeWithStroke(group, 2.0);
styledGroup = new ShapeWithShadow(styledGroup, 3.0);

engine.addShape(styledGroup);
```

---

## 🔄 Pattern Architecture

```
┌─────────────────────────┐
│    Shape (Original)     │ ← Circle, Rectangle, Line, etc.
└────────┬────────────────┘
         │ wrapped by
         ▼
┌─────────────────────────┐
│  ShapeWithStroke        │ ← Decorator 1 (Optional)
│  extends ShapeDecorator │
└────────┬────────────────┘
         │ wraps
         ▼
┌─────────────────────────┐
│  ShapeWithShadow        │ ← Decorator 2 (Optional)
│  extends ShapeDecorator │
└────────┬────────────────┘
         │ wraps
         ▼
┌─────────────────────────┐
│  ShapeWithGradient      │ ← Decorator 3 (Optional)
│  extends ShapeDecorator │
└────────┬────────────────┘
         │ wraps
         ▼
    Final Shape
   (Ready to draw)
```

---

## ✅ Advantages

### Decorator Pattern:
- ✅ Add features WITHOUT modifying existing Shape classes
- ✅ Stack multiple effects dynamically
- ✅ Easy to add new decorators later
- ✅ Single Responsibility Principle

### Composite Pattern:
- ✅ Group shapes logically
- ✅ Treat group as single shape
- ✅ Move/style entire group together
- ✅ Support nested grouping

---

## 📋 Implementation Checklist

- [ ] Create ShapeDecorator.java
- [ ] Create ShapeWithStroke.java
- [ ] Create ShapeWithShadow.java
- [ ] Create ShapeWithGradient.java
- [ ] Create ShapeGroup.java
- [ ] Add imports to FXMLDocumentController.java
- [ ] Add @FXML fields to FXMLDocumentController.java
- [ ] Modify mouse event handler in FXMLDocumentController.java
- [ ] Add UI controls to FXMLDocument.fxml
- [ ] Test with different shape combinations
- [ ] Test decorator stacking
- [ ] Test grouping functionality

---

## 🚀 Future Enhancements

You can easily add more decorators:
- ShapeWithBorder
- ShapeWithRotation
- ShapeWithScale
- ShapeWithAnimation
- ShapeWithPattern
- ShapeWithTransparency

All WITHOUT modifying Shape.java! 🎉
