# 🎨 QUICK REFERENCE - Pattern Classes & Locations

## 📍 FILE PATHS

### Decorator Pattern Classes
```
✅ src/paint/model/ShapeDecorator.java           [Abstract Base]
✅ src/paint/model/ShapeWithStroke.java          [Concrete: Stroke styling]
✅ src/paint/model/ShapeWithShadow.java          [Concrete: Shadow effects]
✅ src/paint/model/ShapeWithGradient.java        [Concrete: Gradient fills]
```

### Composite Pattern Class
```
✅ src/paint/model/ShapeGroup.java               [Composite: Shape grouping]
```

---

## 🎯 ONE-MINUTE OVERVIEW

### DECORATOR PATTERN
**What**: Wraps a shape to add features dynamically
**Where**: `paint.model` package
**How Many Classes**: 4 (1 abstract + 3 concrete)
**Files**: ShapeDecorator.java, ShapeWithStroke.java, ShapeWithShadow.java, ShapeWithGradient.java

**Real-World Example**:
```
Plain Circle → Add Stroke → Stroke Circle → Add Shadow → Shadow+Stroke Circle
```

### COMPOSITE PATTERN
**What**: Groups multiple shapes together, treats them as one
**Where**: `paint.model` package
**How Many Classes**: 1
**File**: ShapeGroup.java

**Real-World Example**:
```
Circle + Rectangle + Line → Group them → Draw/Move/Color entire group
```

---

## 🔗 HOW THEY CONNECT

```
DECORATOR: Circle → ShapeWithStroke → ShapeWithShadow → ShapeWithGradient
                    (enhances single shape)

COMPOSITE: [StrokedCircle, ShadowedRect, GradientLine] → ShapeGroup
           (groups multiple shapes, including decorated ones)

BOTH TOGETHER:
ShapeGroup contains [
    ShapeWithStroke(Circle),
    ShapeWithGradient(Rectangle),
    ShapeWithShadow(Line)
]
```

---

## 📝 USAGE IN CODE

### Create a Decorated Shape
```java
// File: Any controller
iShape circle = new Circle(start, end, Color.RED);
iShape styledCircle = new ShapeWithStroke(circle, 2.0);
iShape finalCircle = new ShapeWithShadow(styledCircle, 3.0);
```

### Create a Group
```java
// File: Any controller
ShapeGroup group = new ShapeGroup();
group.addShape(decoratedCircle);
group.addShape(decoratedRectangle);
group.draw(canvas);
```

---

## 🎨 CURRENT IMPLEMENTATION STATUS

| Class | File | Status | Methods |
|-------|------|--------|---------|
| ShapeDecorator | ✅ Created | Abstract | setPosition, setColor, draw, clone |
| ShapeWithStroke | ✅ Created | Concrete | draw (adds stroke) |
| ShapeWithShadow | ✅ Created | Concrete | draw (adds shadow) |
| ShapeWithGradient | ✅ Created | Concrete | draw (adds gradient) |
| ShapeGroup | ✅ Created | Concrete | addShape, draw, setPosition |

---

## 🚀 CURRENT USAGE POINTS

### In DrawingEngine.java
- Stores shapes in List
- Calls `shape.draw(canvas)` on all

### In ShapeFactory.java
- Creates base shapes that can be decorated

### In FXMLDocumentController.java
- Could add decorator/composite support here

---

## 💡 EXAMPLES IN EACH CLASS

### ShapeWithStroke.java
```java
Line 12: // This decorator adds stroke styling to any shape
Line 23: ShapeWithStroke(iShape shape, double strokeWidth)
Line 31: public void draw(Canvas canvas)
Line 38: gc.setLineWidth(strokeWidth);  // ← Applies stroke
```

### ShapeWithShadow.java
```java
Line 13: // This decorator adds shadow effects to any shape
Line 24: public ShapeWithShadow(iShape shape, double shadowOffset)
Line 35: public void draw(Canvas canvas)
Line 43: gc.setFill(shadowColor);  // ← Applies shadow
```

### ShapeWithGradient.java
```java
Line 16: // This decorator adds gradient fill to any shape
Line 36: public void draw(Canvas canvas)
Line 52: LinearGradient gradient = new LinearGradient(...)
Line 58: gc.setFill(gradient);  // ← Applies gradient
```

### ShapeGroup.java
```java
Line 46: public void addShape(iShape shape)
Line 78: public void draw(Canvas canvas) {
Line 80:     for (iShape shape : shapes)
Line 81:         shape.draw(canvas);  // ← Draws all
```

---

## ✅ WHAT'S WORKING

- ✅ All decorator classes compiled successfully
- ✅ All composite classes compiled successfully
- ✅ App runs with Java 25
- ✅ All clone() methods implemented
- ✅ Full decorator stacking support
- ✅ Full composite grouping support

---

## ⚡ INTEGRATION CHECKLIST

To use these patterns in your Paint app:

- [ ] Import decorators in FXMLDocumentController
- [ ] Add UI checkboxes for decorator options
- [ ] Wrap shapes with decorators when drawing
- [ ] Add grouping button to FXMLController
- [ ] Implement select-multiple → group functionality
- [ ] Update SaveToXML to save decorator/group info
- [ ] Update LoadFromXML to restore decorator/group info

