# EXACT CODE LOCATIONS - Where to Edit for DECORATOR & COMPOSITE Patterns

## 📍 PATTERN #1: DECORATOR - Exact File Locations

### 1️⃣ FXMLDocumentController.java - Import Section
**Line Range**: Lines 1-30 (import statements section)

**Current state**: Has imports like:
```java
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Point2D;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ColorPicker;
// ... other imports
```

**WHAT YOU SHOULD ADD HERE:**
- `import paint.model.ShapeWithStroke;`
- `import paint.model.ShapeWithShadow;`
- `import paint.model.ShapeWithGradient;`

**WHY?**
- Makes decorator classes accessible in controller
- Allows `new ShapeWithStroke(...)` without full package path
- Standard Java import practice

---

### 2️⃣ FXMLDocumentController.java - @FXML Fields Section
**Line Range**: Lines 30-60 (where @FXML fields are declared)

**Current state**: Has fields like:
```java
@FXML
private Button DrawBtn;

@FXML
private Button DeleteBtn;

@FXML
private ComboBox<?> ShapeCombo;

@FXML
private ColorPicker colorPicker;
// ... more fields
```

**WHAT YOU SHOULD ADD HERE:**
```java
// NEW @FXML fields for Decorator controls

@FXML
private CheckBox strokeCheckbox;

@FXML
private TextField strokeWidthInput;

@FXML
private ComboBox<String> strokeStyleCombo;

@FXML
private CheckBox shadowCheckbox;

@FXML
private CheckBox gradientCheckbox;

@FXML
private ColorPicker gradientStartPicker;

@FXML
private ColorPicker gradientEndPicker;
```

**WHY?**
- @FXML annotation connects Java fields to FXML UI elements
- Allows access to UI control values in your code
- These fields will be automatically populated when FXML loads

---

### 3️⃣ FXMLDocumentController.java - Mouse Event Handler (CRITICAL!)
**Line Range**: Find method like `onMouseReleased`, `onMouseDragged`, or `handleMouseRelease`

**Current code structure** (you need to find this):
```java
// Somewhere around line 200-300 (varies by your code)
@FXML
private void onMouseReleased(MouseEvent event) {
    // OR it could be named differently
    
    // Step 1: Get selected shape type
    String shapeType = ShapeCombo.getValue();
    
    // Step 2: Create shape using factory
    iShape shape = ShapeFactory.createShape(
        shapeType,
        startPoint,
        endPoint,
        selectedColor
    );
    
    // Step 3: Add to drawing
    drawingEngine.addShape(shape);
    
    // Step 4: Redraw canvas
    drawCanvas();
}
```

**WHAT YOU SHOULD DO HERE:**
Between Step 2 and Step 3, INSERT the decorator wrapping code:

```java
// AFTER creating the base shape
iShape shape = ShapeFactory.createShape(
    shapeType,
    startPoint,
    endPoint,
    selectedColor
);

// ===== INSERT THIS SECTION =====
// Apply decorators based on checkbox selections

// Check if stroke checkbox exists and is selected
if (strokeCheckbox != null && strokeCheckbox.isSelected()) {
    try {
        double strokeWidth = Double.parseDouble(strokeWidthInput.getText());
        String strokeStyle = strokeStyleCombo.getValue();
        shape = new ShapeWithStroke(shape, strokeWidth, strokeStyle);
    } catch (NumberFormatException e) {
        System.err.println("Invalid stroke width input");
    }
}

// Check if shadow checkbox exists and is selected
if (shadowCheckbox != null && shadowCheckbox.isSelected()) {
    shape = new ShapeWithShadow(shape, 3.0, 3.0, Color.BLACK, 5.0);
}

// Check if gradient checkbox exists and is selected
if (gradientCheckbox != null && gradientCheckbox.isSelected()) {
    Color gradStart = gradientStartPicker.getValue();
    Color gradEnd = gradientEndPicker.getValue();
    if (gradStart != null && gradEnd != null) {
        shape = new ShapeWithGradient(shape, gradStart, gradEnd, true);
    }
}
// ===== END INSERT SECTION =====

// CONTINUE with adding to engine
drawingEngine.addShape(shape);
drawCanvas();
```

**WHY this location?**
- After base shape created but before adding to engine
- Decorators wrap the shape (like layers)
- Each decorator wraps the previous one
- Order matters: Last decorator wraps first decorator
- Example: `new Shadow(new Stroke(new Gradient(baseShape)))`

---

### 4️⃣ FXMLDocument.fxml - UI Controls Addition
**File Location**: `src/paint/view/FXMLDocument.fxml`

**Line Range**: Where other controls are defined (GridPane or VBox section)

**Current structure**: Has elements like:
```xml
<ComboBox fx:id="ShapeCombo" />
<ColorPicker fx:id="colorPicker" />
<Button fx:id="DrawBtn" text="Draw" />
```

**WHAT YOU SHOULD ADD:**
In the same container (GridPane/VBox), add:

```xml
<!-- Stroke Styling Controls -->
<Label text="Stroke Options:" />
<CheckBox fx:id="strokeCheckbox" text="Add Stroke" />
<HBox spacing="5">
    <Label text="Width:" />
    <TextField fx:id="strokeWidthInput" prefWidth="60" promptText="2.0" />
    <Label text="Style:" />
    <ComboBox fx:id="strokeStyleCombo" prefWidth="100">
        <items>
            <FXCollections fx:factory="observableArrayList">
                <String fx:value="solid" />
                <String fx:value="dashed" />
                <String fx:value="dotted" />
            </FXCollections>
        </items>
    </ComboBox>
</HBox>

<!-- Shadow Effect Controls -->
<CheckBox fx:id="shadowCheckbox" text="Add Shadow" />

<!-- Gradient Fill Controls -->
<Label text="Gradient Options:" />
<CheckBox fx:id="gradientCheckbox" text="Use Gradient" />
<HBox spacing="5">
    <Label text="Start Color:" />
    <ColorPicker fx:id="gradientStartPicker" />
    <Label text="End Color:" />
    <ColorPicker fx:id="gradientEndPicker" />
</HBox>
```

**WHY this location?**
- FXML defines the visual UI layout
- fx:id connects to @FXML fields in controller
- CheckBox allows users to toggle effects on/off
- TextFields let users set numeric values (stroke width)
- ComboBox provides dropdown choices (stroke styles)
- ColorPickers let users choose gradient colors

---

## 📍 PATTERN #2: COMPOSITE - Exact File Locations (FUTURE)

### ⏳ DON'T IMPLEMENT YET - Only show where you WOULD

### 1️⃣ ShapeGroup.java - Create New Class (LATER)
**File to Create**: `src/paint/model/ShapeGroup.java`

**Why this location?**
- Same directory as Circle.java, Rectangle.java, etc.
- Implements iShape like other shapes
- Part of model layer

**Where to find iShape.java**:
```
Paint/
├── src/
│   └── paint/
│       └── model/
│           ├── iShape.java        ← Reference this
│           ├── Shape.java
│           ├── Circle.java
│           ├── Rectangle.java
│           ├── Line.java
│           ├── Triangle.java
│           ├── Square.java
│           ├── Ellipse.java
│           └── ShapeGroup.java     ← Create here (LATER)
```

---

### 2️⃣ FXMLDocumentController.java - New Method (LATER)
**Location**: Add new method after existing methods (around line 500+)

**What to add (LATER, not now):**
```java
// NEW METHOD for grouping shapes
@FXML
private void groupSelectedShapes() {
    List<iShape> selectedShapes = getSelectedShapesFromUI();
    
    if (selectedShapes.isEmpty()) {
        showAlert("No shapes selected");
        return;
    }
    
    ShapeGroup group = new ShapeGroup();
    for (iShape shape : selectedShapes) {
        group.addShape(shape);
    }
    
    drawingEngine.addShape(group);
    drawingEngine.removeShapes(selectedShapes);  // Remove individuals
    
    drawCanvas();
}

private List<iShape> getSelectedShapesFromUI() {
    // Logic to get user-selected shapes from canvas
    // This depends on your shape selection mechanism
}
```

**WHY?**
- Separate method for grouping logic
- Keeps concerns organized
- Easy to add "Group" button to UI later

---

### 3️⃣ FXMLDocument.fxml - Group Button (LATER)
**Location**: UI controls section, where buttons are defined

**What to add (LATER):**
```xml
<!-- Group Operations (add these buttons) -->
<Button fx:id="groupButton" text="Group Selected" onAction="#groupSelectedShapes" />
<Button fx:id="ungroupButton" text="Ungroup" onAction="#ungroupSelectedShapes" />
```

**WHY?**
- Gives users UI way to trigger grouping
- onAction links button click to method in controller
- Easy to enable/disable based on selection

---

## 📊 Summary: Edit Locations by Priority

### 🔴 PRIORITY 1 - DO THESE NOW (DECORATOR)

| File | What | Lines | Why |
|------|------|-------|-----|
| FXMLDocumentController.java | Add imports | 1-30 | Make decorators available |
| FXMLDocumentController.java | Add @FXML fields | 30-60 | Connect UI controls |
| FXMLDocumentController.java | Add decorator code | 200-300 (in mouse handler) | Apply effects |
| FXMLDocument.fxml | Add UI controls | Variable | Give users options |

### 🟡 PRIORITY 2 - DO THESE LATER (COMPOSITE)

| File | What | Lines | Why |
|------|------|-------|-----|
| ShapeGroup.java | Create new file | N/A | Implement grouping |
| FXMLDocumentController.java | Add grouping method | 500+ | Handle group creation |
| FXMLDocument.fxml | Add group buttons | Variable | UI for grouping |

---

## 🎯 Quick Navigation Guide

**To find where you're editing:**

### Finding FXMLDocumentController.java:
```
Paint/
└── src/
    └── paint/
        └── controller/
            └── FXMLDocumentController.java  ← HERE
```

### Finding FXMLDocument.fxml:
```
Paint/
└── src/
    └── paint/
        └── view/
            └── FXMLDocument.fxml  ← HERE
```

### Finding existing Shape classes (reference):
```
Paint/
└── src/
    └── paint/
        └── model/
            ├── Shape.java
            ├── Circle.java
            ├── Rectangle.java
            ├── iShape.java
            └── ... (other shapes)
```

### New files to CREATE (DECORATOR):
```
Paint/
└── src/
    └── paint/
        └── model/
            ├── ShapeDecorator.java         ← NEW
            ├── ShapeWithStroke.java        ← NEW
            ├── ShapeWithShadow.java        ← NEW
            ├── ShapeWithGradient.java      ← NEW
            └── ... (existing shapes)
```

---

## ⚠️ CRITICAL: Do NOT Edit These Files

| File | Reason | Consequence |
|------|--------|-------------|
| Shape.java | Base class needed unchanged | ❌ Breaks all shapes |
| Circle.java | Works perfectly as-is | ❌ Unnecessary complexity |
| Rectangle.java | Decorators handle styling | ❌ Creates duplicates |
| Line.java | Clean single responsibility | ❌ Maintenance nightmare |
| Triangle.java | No modifications needed | ❌ Introduces bugs |
| iShape.java | Decorators implement it | ❌ Breaks interface contract |
| ShapeFactory.java | Creates base shapes (decorator wraps) | ❌ Lost flexibility |

---

## 🎓 Why This Edit Strategy?

### Separation of Concerns:
- **Shape classes** = What shapes ARE
- **Decorators** = Extra effects/styling
- **Controller** = User interactions
- **FXML** = Visual UI layout

### Open/Closed Principle:
- ✅ OPEN for extension: Add new decorators easily
- ✅ CLOSED for modification: Existing code unchanged

### Single Responsibility:
- Each file does one thing well
- Each decorator handles one concern
- Easy to test each piece independently

### Scalability:
- Add new decorator → Create new class
- No ripple effects to existing code
- Easy for future developers to understand

---

