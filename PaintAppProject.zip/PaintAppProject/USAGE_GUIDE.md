# Quick Start - Using Patterns in Paint App

## ✨ NEW FEATURES

### DECORATOR CHECKBOXES (Top Toolbar)
```
☐ Add Stroke      → Adds black outline to shape
☐ Add Shadow      → Adds shadow/glow effect
☐ Add Gradient    → Adds color gradient fill
```

### GROUP BUTTON (Top Toolbar)
```
[Group] → Groups selected shapes into one unit
```

---

## 🎯 TUTORIAL 1: ADD EFFECTS TO SHAPES (Decorator)

### Step 1: Select a Shape
```
1. Click "Shape" dropdown
2. Select "Circle" (or any shape)
3. Pick a color from the color picker
```

### Step 2: Check Boxes for Effects
```
1. Check "Add Stroke" ✓
2. Check "Add Shadow" ✓
3. Leave "Add Gradient" unchecked
```

### Step 3: Draw the Shape
```
1. Click on canvas and drag to draw
2. Release mouse
3. Shape appears with stroke + shadow effects!
```

### Result
```
Circle with:
✓ Black outline (Stroke)
✓ Dark shadow behind it (Shadow)
```

---

## 🎯 TUTORIAL 2: COMBINE EFFECTS (Chaining Decorators)

### Create Super-Decorated Shape
```
1. Check ALL THREE boxes:
   ☑ Add Stroke
   ☑ Add Shadow  
   ☑ Add Gradient
   
2. Pick a bright color (e.g., Blue)

3. Draw a Rectangle

4. Result: Rectangle with ALL effects:
   - Stroke outline
   - Shadow effect
   - Blue → White gradient fill
```

---

## 🎯 TUTORIAL 3: GROUP SHAPES (Composite)

### Step 1: Draw Multiple Shapes
```
1. Draw Circle (with or without effects)
2. Draw Rectangle (with or without effects)
3. Draw Triangle (with or without effects)
```

### Step 2: Select Shapes to Group
```
In the Shape List (right panel):
1. Click first shape
2. Hold Ctrl and click second shape
3. Hold Ctrl and click third shape

All 3 should be highlighted!
```

### Step 3: Click Group Button
```
1. Click the gold [Group] button
2. See message: "✓ Grouped 3 shapes successfully!"
3. In shape list, shapes combine into "ShapeGroup"
```

### Step 4: Move/Transform Group
```
1. Select the group in shape list
2. Use Move button to move entire group
3. Use Resize button to resize entire group
4. All shapes move together as one!
```

---

## 🎯 TUTORIAL 4: ADVANCED - NESTED GROUPING

### Create Groups of Groups
```
Step 1: Create Group A
- Draw 3 decorated shapes
- Group them → "ShapeGroup"

Step 2: Create Group B  
- Draw 2 more decorated shapes
- Group them → another "ShapeGroup"

Step 3: Group the Groups!
- Select both ShapeGroup objects (Ctrl+Click)
- Click [Group] button
- Now you have a group of groups!

This creates: ShapeGroup(ShapeGroup, ShapeGroup)
```

---

## 💡 PRO TIPS

### Tip 1: Decorators Stack
```
Every decorator adds a LAYER:
Draw Circle
  → Wrapped by ShapeWithStroke
    → Wrapped by ShapeWithShadow  
      → Wrapped by ShapeWithGradient
        = Circle with 3 effects!
```

### Tip 2: Mix Checked/Unchecked
```
Create variety:
- Shape 1: ☑☐☐ (Only Stroke)
- Shape 2: ☐☑☐ (Only Shadow)
- Shape 3: ☐☐☑ (Only Gradient)
- Shape 4: ☑☑☑ (All 3)
```

### Tip 3: Group After Decorating
```
Best practice:
1. First, add decorators to individual shapes
2. Then, group the decorated shapes
3. This preserves decorator effects in group!
```

### Tip 4: Ungrouping
```
To "ungroup":
1. Delete the group
2. Redraw/recreate individual shapes
3. Re-add decorators
(Or implement UnGroup feature!)
```

---

## 📋 QUICK REFERENCE

| What You Want | How to Do It |
|---|---|
| Outline on shape | ☑Add Stroke |
| Shadow effect | ☑Add Shadow |
| Color gradient | ☑Add Gradient |
| Multiple effects | ☑☑☑ Check all |
| Group shapes | Select + [Group] button |
| Move group | Select group + Move button |
| Resize group | Select group + Resize button |

---

## ⚠️ COMMON ISSUES

### Issue: "Select at least 2 shapes to group"
```
Solution: You need to select minimum 2 shapes
1. Ctrl+Click first shape
2. Ctrl+Click second shape  
3. Then click Group
```

### Issue: Decorators not visible
```
Solution: Checkbox might be unchecked
1. Check the decorator checkbox
2. Draw shape fresh
3. Decorators appear on NEW shapes only
```

### Issue: Group button doesn't work
```
Solution: Make sure shapes are actually selected
1. Look at Shape List (right panel)
2. Shapes should be highlighted in blue
3. Then click Group button
```

---

## 🎨 Example Scene

### Create This:
```
A group containing:
- Decorated Circle (red stroke, shadow, gradient)
- Decorated Rectangle (blue stroke, no shadow, gradient)  
- Decorated Triangle (green stroke, shadow, no gradient)

All grouped and moveable as ONE unit!
```

### Steps:
```
1. ☑Add Stroke, ☑Add Shadow, ☑Add Gradient → Draw Circle
2. ☑Add Stroke, ☐Add Shadow, ☑Add Gradient → Draw Rectangle
3. ☑Add Stroke, ☑Add Shadow, ☐Add Gradient → Draw Triangle
4. Ctrl+Click all three in shape list
5. Click [Group]
6. Move/resize the group!
```

---

**You now have FULL integration of Decorator and Composite patterns!** 🎉

Try it out and let me know if you have questions!
