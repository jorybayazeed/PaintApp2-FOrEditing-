# 🏗️ CLASS RELATIONSHIPS & IMPLEMENTATION DETAILS

## 1️⃣ DECORATOR PATTERN - Class Hierarchy

### iShape Interface (All Classes Implement)
```java
public interface iShape extends Cloneable {
    void setPosition(Point2D position);
    Point2D getPosition();
    void setColor(Color color);
    Color getColor();
    void setFillColor(Color color);
    Color getFillColor();
    void draw(Canvas canvas);
    iShape clone() throws CloneNotSupportedException;
    void setProperties(Map<String, Double> properties);
    Map<String, Double> getProperties();
}
```

### ShapeDecorator (Abstract Base Class)
```java
public abstract class ShapeDecorator implements iShape {
    protected iShape wrappedShape;              // ← Stores wrapped shape
    
    public ShapeDecorator(iShape shape) {
        this.wrappedShape = shape;              // ← Composition
    }
    
    @Override
    public void setPosition(Point2D position) {
        wrappedShape.setPosition(position);     // ← Delegation
    }
    
    @Override
    public void draw(Canvas canvas) {
        wrappedShape.draw(canvas);              // ← Base draws wrapped
    }
    
    @Override
    public abstract iShape clone() throws CloneNotSupportedException; // ← Force subclasses to implement
}
```

### ShapeWithStroke (Concrete Decorator 1)
```java
public class ShapeWithStroke extends ShapeDecorator {
    private double strokeWidth;
    private String strokeStyle;
    
    @Override
    public void draw(Canvas canvas) {           // ← Override to add behavior
        GraphicsContext gc = canvas.getGraphicsContext2D();
        double originalWidth = gc.getLineWidth();
        
        gc.setLineWidth(strokeWidth);           // ← Add stroke effect
        
        if ("dashed".equals(strokeStyle)) {
            gc.setLineDashes(5, 5);
        }
        
        wrappedShape.draw(canvas);              // ← Call wrapped shape's draw
        gc.setLineWidth(originalWidth);
    }
    
    @Override
    public iShape clone() throws CloneNotSupportedException {
        iShape clonedInner = wrappedShape.clone(); // ← Clone wrapped
        return new ShapeWithStroke(clonedInner, strokeWidth, strokeStyle);
    }
}
```

### ShapeWithShadow (Concrete Decorator 2)
```java
public class ShapeWithShadow extends ShapeDecorator {
    private double shadowOffsetX;
    private double shadowOffsetY;
    private Color shadowColor;
    
    @Override
    public void draw(Canvas canvas) {
        GraphicsContext gc = canvas.getGraphicsContext2D();
        Color originalColor = (Color) gc.getFill();
        
        gc.setFill(shadowColor);                // ← Add shadow effect
        wrappedShape.draw(canvas);              // ← Draw shadow version
        
        gc.setFill(originalColor);
        wrappedShape.draw(canvas);              // ← Draw on top
    }
    
    @Override
    public iShape clone() throws CloneNotSupportedException {
        iShape clonedInner = wrappedShape.clone();
        return new ShapeWithShadow(clonedInner, shadowOffsetX, shadowOffsetY, shadowColor);
    }
}
```

### ShapeWithGradient (Concrete Decorator 3)
```java
public class ShapeWithGradient extends ShapeDecorator {
    private Color colorStart;
    private Color colorEnd;
    private boolean isHorizontal;
    
    @Override
    public void draw(Canvas canvas) {
        GraphicsContext gc = canvas.getGraphicsContext2D();
        
        Stop[] stops = new Stop[] {
            new Stop(0, colorStart),
            new Stop(1, colorEnd)
        };
        
        LinearGradient gradient = new LinearGradient(...); // ← Create gradient
        gc.setFill(gradient);                   // ← Add gradient effect
        wrappedShape.draw(canvas);              // ← Draw with gradient
    }
    
    @Override
    public iShape clone() throws CloneNotSupportedException {
        iShape clonedInner = wrappedShape.clone();
        return new ShapeWithGradient(clonedInner, colorStart, colorEnd, isHorizontal);
    }
}
```

---

## 2️⃣ COMPOSITE PATTERN - Class Structure

### ShapeGroup (Implements iShape Like All Others)
```java
public class ShapeGroup implements iShape {
    private List<iShape> shapes = new ArrayList<>();  // ← Contains many shapes
    private Point2D groupPosition;
    private Color groupColor;
    private Color groupFillColor;
    
    // Key Methods
    public void addShape(iShape shape) {
        if (shape != null) {
            shapes.add(shape);                  // ← Add shape (any iShape: base, decorated, or group)
        }
    }
    
    @Override
    public void draw(Canvas canvas) {
        for (iShape shape : shapes) {           // ← Iterate all
            shape.draw(canvas);                 // ← Draw each
        }
    }
    
    @Override
    public void setPosition(Point2D position) {
        this.groupPosition = position;
        for (iShape shape : shapes) {           // ← Affect all
            shape.setPosition(position);        // ← Move all
        }
    }
    
    @Override
    public void setColor(Color color) {
        this.groupColor = color;
        for (iShape shape : shapes) {           // ← Affect all
            shape.setColor(color);              // ← Color all
        }
    }
    
    @Override
    public iShape clone() throws CloneNotSupportedException {
        ShapeGroup clonedGroup = new ShapeGroup();
        for (iShape shape : shapes) {
            clonedGroup.addShape(shape.clone()); // ← Clone all shapes
        }
        return clonedGroup;
    }
}
```

---

## 3️⃣ PATTERN COMBINATIONS

### Decorator Chain (Linear)
```
Circle
  ↓ wrapped by
ShapeWithStroke(Circle)
  ↓ wrapped by
ShapeWithShadow(ShapeWithStroke(Circle))
  ↓ wrapped by
ShapeWithGradient(ShapeWithShadow(ShapeWithStroke(Circle)))

Result: One decorated circle with 3 effects stacked
```

### Composite (Hierarchical)
```
ShapeGroup {
    Circle,
    Rectangle,
    Line,
    ShapeGroup {           ← Nested group
        Triangle,
        Square
    }
}

Result: One group containing multiple shapes (including another group)
```

### Combined (Best of Both)
```
ShapeGroup {
    ShapeWithStroke(Circle),              ← Decorated
    ShapeWithGradient(Rectangle),         ← Decorated
    ShapeWithShadow(Line),                ← Decorated
    ShapeGroup {                          ← Nested group
        ShapeWithStroke(Triangle),        ← Decorated
        ShapeWithShadow(Square)           ← Decorated
    }
}

Result: Complex structure with nested groups and decorations
```

---

## 4️⃣ HOW WRAPPING WORKS (Decorator Example)

### Step-by-Step Execution

```
// Create base circle
Circle circle = new Circle(p1, p2, Color.RED);

// Wrap 1: Add stroke
ShapeWithStroke strokedCircle = new ShapeWithStroke(circle, 2.0);
// strokedCircle.wrappedShape = circle

// Wrap 2: Add shadow
ShapeWithShadow shadowedCircle = new ShapeWithShadow(strokedCircle, 4.0);
// shadowedCircle.wrappedShape = strokedCircle

// Wrap 3: Add gradient
ShapeWithGradient finalCircle = new ShapeWithGradient(shadowedCircle, RED, BLUE);
// finalCircle.wrappedShape = shadowedCircle

// When you call draw:
finalCircle.draw(canvas)
    ↓
ShapeWithGradient.draw() {
    apply gradient fill
    shadowedCircle.draw(canvas)           // Call wrapped
        ↓
        ShapeWithShadow.draw() {
            apply shadow color
            strokedCircle.draw(canvas)    // Call wrapped
                ↓
                ShapeWithStroke.draw() {
                    apply stroke width
                    circle.draw(canvas)   // Call wrapped
                        ↓
                        Circle.draw()
                        {
                            Draw circle at base level
                        }
                    restore stroke width
                }
            restore shadow color
        }
    restore gradient fill
}
```

---

## 5️⃣ POLYMORPHISM IN ACTION

### Why This Works (All Implement iShape)

```java
// All these are iShape:
iShape base = new Circle(...);
iShape decorated1 = new ShapeWithStroke(base, 2.0);
iShape decorated2 = new ShapeWithShadow(decorated1, 4.0);
iShape group = new ShapeGroup();

// Can be treated the same way:
List<iShape> shapes = new ArrayList<>();
shapes.add(base);           // Base shape
shapes.add(decorated2);     // Decorated shape
shapes.add(group);          // Composite

// Generic drawing works on all:
for (iShape shape : shapes) {
    shape.draw(canvas);     // Works on any!
}
```

---

## 6️⃣ REAL EXAMPLE: Creating a Beautiful Circle

```java
// Step 1: Create base circle (Factory Pattern)
iShape circle = ShapeFactory.createShape("Circle", 
    new Point2D(100, 100), 
    new Point2D(150, 150), 
    Color.RED
);

// Step 2: Add effects (Decorator Pattern)
iShape decoratedCircle = 
    new ShapeWithGradient(
        new ShapeWithShadow(
            new ShapeWithStroke(circle, 3.0, "solid"),
            5.0
        ),
        Color.RED,
        Color.YELLOW
    );

// Step 3: Store in group (Composite Pattern)
ShapeGroup drawing = new ShapeGroup();
drawing.addShape(decoratedCircle);

// Step 4: Draw everything
drawing.draw(canvas);

// Result: A red circle with thick solid stroke, shadow effect, and red-to-yellow gradient fill
```

---

## 7️⃣ KEY DESIGN PRINCIPLES

### 1. Single Responsibility
- ShapeWithStroke only handles stroke
- ShapeWithShadow only handles shadow
- ShapeWithGradient only handles gradient
- ShapeGroup only handles grouping

### 2. Open/Closed Principle
- Can add new decorators without modifying existing ones
- Can add new shapes without modifying decorators or composite

### 3. Liskov Substitution
- Any iShape can be used wherever iShape is expected
- Circle, ShapeWithStroke, ShapeGroup all work the same way

### 4. Composition Over Inheritance
- Instead of creating 100 subclasses of Circle:
  - StrokedCircle
  - ShadowedCircle
  - GradientCircle
  - StrokedShadowedCircle
  - ...etc
- We compose decorators on demand

---

## 8️⃣ SUMMARY OF RELATIONSHIPS

```
iShape Interface
├── Shape (abstract)
│   ├── Circle (base)
│   ├── Rectangle (base)
│   ├── Line (base)
│   └── ... (other base shapes)
│
├── ShapeDecorator (abstract)
│   ├── ShapeWithStroke
│   ├── ShapeWithShadow
│   └── ShapeWithGradient
│
└── ShapeGroup (composite)
    └── Can contain any iShape (including other groups)
```

All work together seamlessly because they all implement iShape!

