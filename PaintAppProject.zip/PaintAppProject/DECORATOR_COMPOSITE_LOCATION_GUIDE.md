# 📍 DECORATOR & COMPOSITE PATTERN - Location & Usage Guide

## 📁 File Locations

### DECORATOR PATTERN Files

#### 1. **ShapeDecorator.java** (Abstract Base Class)
```
📂 src/paint/model/ShapeDecorator.java
```
- **Purpose**: Abstract base class for all decorators
- **Key Feature**: Wraps an `iShape` using composition
- **Field**: `protected iShape wrappedShape;`
- **Methods**: Delegates all methods to wrapped shape by default

#### 2. **ShapeWithStroke.java** (Concrete Decorator 1)
```
📂 src/paint/model/ShapeWithStroke.java
```
- **Purpose**: Adds stroke styling to any shape
- **Extends**: `ShapeDecorator`
- **Features**:
  - Stroke width (1.0, 2.0, 3.0, etc.)
  - Stroke style (solid, dashed, dotted)
- **Key Method**: `draw(Canvas canvas)` - applies stroke properties before drawing

#### 3. **ShapeWithShadow.java** (Concrete Decorator 2)
```
📂 src/paint/model/ShapeWithShadow.java
```
- **Purpose**: Adds shadow effects to any shape
- **Extends**: `ShapeDecorator`
- **Features**:
  - Shadow offset (X, Y coordinates)
  - Shadow color
  - Shadow blur effect
- **Key Method**: `draw(Canvas canvas)` - draws shadow then shape

#### 4. **ShapeWithGradient.java** (Concrete Decorator 3)
```
📂 src/paint/model/ShapeWithGradient.java
```
- **Purpose**: Adds gradient fill to any shape
- **Extends**: `ShapeDecorator`
- **Features**:
  - Start color and end color
  - Horizontal or vertical gradient
  - LinearGradient implementation
- **Key Method**: `draw(Canvas canvas)` - applies gradient fill

---

### COMPOSITE PATTERN File

#### **ShapeGroup.java** (Composite)
```
📂 src/paint/model/ShapeGroup.java
```
- **Purpose**: Treats a group of shapes as a single shape
- **Implements**: `iShape` interface
- **Data Structure**: `List<iShape> shapes`
- **Key Methods**:
  - `addShape(iShape shape)` - adds individual or decorated shapes
  - `removeShape(iShape shape)` - removes shapes
  - `draw(Canvas canvas)` - draws all shapes in order
  - `setPosition(Point2D position)` - moves entire group
  - `setColor(Color color)` - colors entire group
  - `clone()` - clones all shapes in group

---

## 🎯 WHERE THEY ARE USED

### Currently Used In:
1. **Drawing Engine** (DrawingEngine.java)
   - Stores shapes in a list
   - Could use ShapeGroup to group selected shapes

2. **Controller** (FXMLDocumentController.java)
   - Could be enhanced to support decorator/composite creation

### How They Work Together

```
┌──────────────────────────────────────────┐
│        Base Shape                        │
│     (Circle, Rectangle, Line)            │
│  implements iShape                       │
└────────────┬─────────────────────────────┘
             │
             │ wrapped by DECORATOR
             ▼
┌──────────────────────────────────────────┐
│     ShapeWithStroke                      │
│  extends ShapeDecorator                  │
│  adds stroke styling                     │
└────────────┬─────────────────────────────┘
             │
             │ wrapped by another DECORATOR
             ▼
┌──────────────────────────────────────────┐
│     ShapeWithShadow                      │
│  extends ShapeDecorator                  │
│  adds shadow effect                      │
└────────────┬─────────────────────────────┘
             │
             │ wrapped by another DECORATOR
             ▼
┌──────────────────────────────────────────┐
│     ShapeWithGradient                    │
│  extends ShapeDecorator                  │
│  adds gradient fill                      │
└──────────────────────────────────────────┘


Multiple DECORATED shapes stored in COMPOSITE:

┌────────────────────────────────────────────┐
│          ShapeGroup (COMPOSITE)            │
│                                            │
│  ├─ StrokedCircle                          │
│  ├─ ShadowedRectangle                      │
│  ├─ GradientLine                           │
│  └─ Another ShapeGroup (NESTED!)           │
│       ├─ StrokedTriangle                   │
│       └─ ShadowedSquare                    │
│                                            │
│  draw() → draws ALL in order              │
│  setColor() → colors ALL                  │
│  setPosition() → moves ALL                │
└────────────────────────────────────────────┘
```

---

## 💡 USAGE EXAMPLES

### Example 1: Single Decorator
```java
// Create a base shape
iShape circle = new Circle(startPoint, endPoint, Color.BLUE);

// Wrap it with a stroke decorator
iShape styledCircle = new ShapeWithStroke(circle, 3.0, "solid");

// Draw it
styledCircle.draw(canvas);
```

### Example 2: Multiple Decorators (Composition)
```java
// Create base shape
iShape rectangle = new Rectangle(startPoint, endPoint, Color.RED);

// Layer 1: Add stroke
iShape strokedRect = new ShapeWithStroke(rectangle, 2.0);

// Layer 2: Add shadow
iShape shadowedRect = new ShapeWithShadow(strokedRect, 4.0);

// Layer 3: Add gradient
iShape gradientRect = new ShapeWithGradient(shadowedRect, Color.RED, Color.YELLOW);

// Draw final result (all effects combined!)
gradientRect.draw(canvas);
```

### Example 3: Composite Pattern
```java
// Create a group
iShape group = new ShapeGroup();

// Add shapes to group
((ShapeGroup)group).addShape(new Circle(p1, p2, Color.RED));
((ShapeGroup)group).addShape(new Rectangle(p3, p4, Color.BLUE));
((ShapeGroup)group).addShape(new Line(p5, p6, Color.GREEN));

// Draw all shapes at once
group.draw(canvas);

// Move all shapes at once
group.setPosition(new Point2D(100, 100));

// Color all shapes at once
group.setColor(Color.BLACK);
```

### Example 4: Composite + Decorator Combination
```java
// Create a group
ShapeGroup group = new ShapeGroup();

// Add decorated shapes to group
iShape styledCircle = new ShapeWithStroke(
    new Circle(p1, p2, Color.RED), 
    2.0
);
group.addShape(styledCircle);

iShape styledRect = new ShapeWithGradient(
    new Rectangle(p3, p4, Color.BLUE), 
    Color.BLUE, 
    Color.CYAN
);
group.addShape(styledRect);

// Draw entire group (all with their decorations)
group.draw(canvas);

// Clone entire group
iShape clonedGroup = group.clone();
```

---

## 🔧 Integration Points in Your Project

### 1. **DrawingEngine.java** (Currently Uses)
- Stores shapes in a List
- Could use ShapeGroup to group multiple shapes
- Already calls `shape.draw(canvas)` on all shapes

### 2. **FXMLDocumentController.java** (Should Use)
- When user draws a shape: could apply decorators
- When user selects "Add Stroke": wrap in ShapeWithStroke
- When user selects "Add Shadow": wrap in ShapeWithShadow
- When user selects "Group": create ShapeGroup

### 3. **ShapeFactory.java** (Already Used)
- Creates base shapes
- Decorators wrap the factory output

---

## 📊 Class Hierarchy

```
iShape (interface)
├── Shape (abstract class)
│   ├── Circle
│   ├── Rectangle
│   ├── Line
│   ├── Triangle
│   ├── Square
│   ├── Ellipse
│   └── ShapeDecorator (abstract) ← DECORATOR BASE
│       ├── ShapeWithStroke
│       ├── ShapeWithShadow
│       └── ShapeWithGradient
└── ShapeGroup ← COMPOSITE
```

---

## ✨ Key Differences

| Aspect | Decorator | Composite |
|--------|-----------|-----------|
| **Purpose** | Add features to single shape | Group multiple shapes |
| **Structure** | Wraps ONE shape | Contains MANY shapes |
| **Use Case** | Styling (stroke, shadow, gradient) | Grouping/Organization |
| **Nesting** | Yes (decorators stack) | Yes (groups contain groups) |
| **Result** | Enhanced single shape | Single unit from many |

---

## 🚀 Next Steps for Integration

To fully integrate these patterns into your Paint app:

1. **In FXMLDocumentController.java**:
   - Add UI controls for decorator options
   - When drawing, check which decorators are selected
   - Wrap base shape with decorators before storing

2. **In DrawingEngine.java**:
   - Add grouping functionality
   - Support selecting multiple shapes
   - Support ungrouping shapes

3. **In LoadFromXML.java / SaveToXML.java**:
   - Serialize/deserialize decorated shapes
   - Serialize/deserialize groups

