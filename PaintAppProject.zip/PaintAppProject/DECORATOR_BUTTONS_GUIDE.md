# 🎨 Paint App - Decorator Buttons Guide

## WHERE TO FIND THE BUTTONS

When you **click START** in the Paint App, the toolbar at the TOP will show:

```
═══════════════════════════════════════════════════════════════════════════
│ [Shape ▼] [Color 🎨] [Recolor] [Move] [Copy] [Resize]                  │
│                                                                         │
│ [Stroke] [Shadow] [Gradient] [Group]                                   │
│   RED     TEAL     GREEN      GOLD                                      │
═══════════════════════════════════════════════════════════════════════════
```

## THE 4 NEW DECORATOR BUTTONS

### 1️⃣ **STROKE BUTTON** (Red)
- **Click it** = Toggle outline effect ON/OFF
- When ON (dark): Shapes will have **BLACK OUTLINE**
- When OFF (light): No outline

### 2️⃣ **SHADOW BUTTON** (Teal)  
- **Click it** = Toggle shadow effect ON/OFF
- When ON (dark): Shapes will have **DARK SHADOW**
- When OFF (light): No shadow

### 3️⃣ **GRADIENT BUTTON** (Green)
- **Click it** = Toggle gradient effect ON/OFF
- When ON (dark): Shapes will have **COLOR BLEND** (color → white)
- When OFF (light): No gradient

### 4️⃣ **GROUP BUTTON** (Gold)
- Select 2+ shapes then click to **GROUP THEM**

---

## HOW TO USE STEP-BY-STEP

### Example: Draw Circle with ALL Effects

```
STEP 1: Click "Start" button (blue button in middle)
        ↓ Drawing toolbar appears

STEP 2: Select Shape
        Click [Shape ▼] dropdown → Select "Circle"

STEP 3: Pick Color
        Click color picker → Choose any color (e.g., Blue)

STEP 4: ENABLE DECORATORS
        Click [Stroke]   → turns DARK RED ✓
        Click [Shadow]   → turns DARK TEAL ✓
        Click [Gradient] → turns DARK GREEN ✓

STEP 5: DRAW
        Click on WHITE CANVAS area
        Drag mouse to draw circle
        Release mouse

STEP 6: RESULT
        Circle appears with:
        ✓ Black outline (Stroke)
        ✓ Dark shadow (Shadow)
        ✓ Blue to white gradient (Gradient)
```

---

## BUTTON STATE INDICATORS

```
LIGHT COLOR = Effect is OFF (disabled)
┌─────────────┐
│   Stroke    │ ← Light Red = NO outline
└─────────────┘

DARK COLOR = Effect is ON (enabled)
┌─────────────┐
│   Stroke    │ ← Dark Red = YES outline
└─────────────┘
```

---

## PRACTICE SCENARIOS

### Scenario 1: Only Stroke
```
1. Click [Stroke]   → Dark Red ✓
2. Click [Shadow]   → Light Teal (OFF)
3. Click [Gradient] → Light Green (OFF)
4. Draw Rectangle
→ Result: Rectangle with just BLACK OUTLINE
```

### Scenario 2: Only Gradient
```
1. Click [Stroke]   → Light Red (OFF)
2. Click [Shadow]   → Light Teal (OFF)
3. Click [Gradient] → Dark Green ✓
4. Draw Triangle
→ Result: Triangle with just GRADIENT FILL
```

### Scenario 3: Stroke + Shadow
```
1. Click [Stroke]   → Dark Red ✓
2. Click [Shadow]   → Dark Teal ✓
3. Click [Gradient] → Light Green (OFF)
4. Draw Line
→ Result: Line with OUTLINE + SHADOW
```

### Scenario 4: All Effects
```
1. Click [Stroke]   → Dark Red ✓
2. Click [Shadow]   → Dark Teal ✓
3. Click [Gradient] → Dark Green ✓
4. Draw Ellipse
→ Result: Ellipse with OUTLINE + SHADOW + GRADIENT
```

---

## 🎯 QUICK CHECKLIST

- ✅ Can you see "Start" button on first screen?
- ✅ Can you click "Start"?
- ✅ Can you see the colored buttons (Red, Teal, Green, Gold)?
- ✅ Can you click each button (colors change)?
- ✅ Can you select a shape from dropdown?
- ✅ Can you pick a color?
- ✅ Can you draw on the white canvas?
- ✅ Do shapes appear with decorators?

---

## 💡 TIPS

1. **Click buttons to toggle** - Dark = ON, Light = OFF
2. **Click BEFORE drawing** - Effects apply to NEW shapes only
3. **You can change effects** - Click buttons again to turn off
4. **Combine effects** - Click multiple buttons for multiple effects
5. **Draw many shapes** - Each with different effect combinations

---

## 🆘 TROUBLESHOOTING

| Issue | Solution |
|-------|----------|
| Can't see buttons | Click "Start" first - toolbar appears after |
| Buttons not changing color when clicked | Try clicking again, or close app and restart |
| Shapes not appearing | Make sure you're dragging on WHITE canvas area |
| Decorators not visible | Check button is DARK (ON) before drawing |
| Old app still showing | Close app completely, then run fresh |

---

## WHAT'S HAPPENING BEHIND THE SCENES

When you click **[Stroke]** button:
- `addStroke` flag toggles: `false` → `true` or `true` → `false`
- Button color changes to show current state
- Next shape you draw will be WRAPPED with `ShapeWithStroke` class
- This is the **DECORATOR PATTERN** in action! 🎨

Same for **[Shadow]** and **[Gradient]** buttons - each wraps the shape!

---

**Try it now! Click the buttons and draw shapes!** 🚀
