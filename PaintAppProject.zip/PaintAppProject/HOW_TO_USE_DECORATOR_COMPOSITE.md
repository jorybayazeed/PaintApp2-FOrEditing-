# HOW TO USE DECORATOR & COMPOSITE PATTERNS IN PAINT APP

## 📍 WHERE THE PATTERNS ARE LOCATED

### 1. **DECORATOR PATTERN CLASSES** (Located in `src/paint/model/`)
```
├── ShapeDecorator.java (Abstract Base)
├── ShapeWithStroke.java (Concrete - Adds stroke styling)
├── ShapeWithShadow.java (Concrete - Adds shadow effect)
└── ShapeWithGradient.java (Concrete - Adds gradient fill)
```

### 2. **COMPOSITE PATTERN CLASS** (Located in `src/paint/model/`)
```
└── ShapeGroup.java (Groups multiple shapes together)
```

---

## 🎯 HOW TO USE THEM IN THE RUNNING APP

### **SCENARIO 1: Using DECORATOR Pattern (Add Effects to Shapes)**

**Current Flow (Without Decorator):**
```
User draws circle → Circle created → Circle drawn
```

**With Decorator Pattern:**
```
User draws circle → Circle created → Wrap with effects → Enhanced circle drawn
```

#### **Step-by-step in FXMLDocumentController:**

**Current code (Line ~280):**
```java
Shape sh;
sh = new ShapeFactory().createShape(type, start, end, ColorBox.getValue());
addShape(sh);
sh.draw(CanvasBox);
```

**How to add STROKE effect (after line 280):**
```java
Shape sh;
sh = new ShapeFactory().createShape(type, start, end, ColorBox.getValue());

// ✨ ADD DECORATOR: Wrap with stroke styling
iShape styledShape = new ShapeWithStroke((iShape) sh, 3.0, "solid");

addShape((Shape) styledShape);
styledShape.draw(CanvasBox);
```

**How to add SHADOW effect:**
```java
iShape styledShape = new ShapeWithStroke((iShape) sh, 3.0, "solid");
iShape shadowedShape = new ShapeWithShadow(styledShape, 4.0); // Add shadow

addShape((Shape) shadowedShape);
shadowedShape.draw(CanvasBox);
```

**How to add GRADIENT effect:**
```java
iShape styledShape = new ShapeWithStroke((iShape) sh, 3.0, "solid");
iShape shadowedShape = new ShapeWithShadow(styledShape, 4.0);
iShape gradientShape = new ShapeWithGradient(shadowedShape, Color.RED, Color.BLUE); // Add gradient

addShape((Shape) gradientShape);
gradientShape.draw(CanvasBox);
```

#### **UI Control Approach (Recommended):**

**Add checkboxes to FXML:**
```xml
<CheckBox fx:id="addStrokeCheckbox" text="Add Stroke" />
<CheckBox fx:id="addShadowCheckbox" text="Add Shadow" />
<CheckBox fx:id="addGradientCheckbox" text="Add Gradient" />
<ColorPicker fx:id="gradientStartColor" />
<ColorPicker fx:id="gradientEndColor" />
```

**Then in FXMLDocumentController:**
```java
@FXML
private CheckBox addStrokeCheckbox;
@FXML
private CheckBox addShadowCheckbox;
@FXML
private CheckBox addGradientCheckbox;
@FXML
private ColorPicker gradientStartColor;
@FXML
private ColorPicker gradientEndColor;

// In onMouseReleased() method:
Shape sh = new ShapeFactory().createShape(type, start, end, ColorBox.getValue());
iShape decoratedShape = (iShape) sh;

// Apply decorators based on checkbox selections
if (addStrokeCheckbox.isSelected()) {
    decoratedShape = new ShapeWithStroke(decoratedShape, 2.0, "solid");
}

if (addShadowCheckbox.isSelected()) {
    decoratedShape = new ShapeWithShadow(decoratedShape, 3.0);
}

if (addGradientCheckbox.isSelected()) {
    decoratedShape = new ShapeWithGradient(
        decoratedShape,
        gradientStartColor.getValue(),
        gradientEndColor.getValue()
    );
}

addShape((Shape) decoratedShape);
decoratedShape.draw(CanvasBox);
```

---

### **SCENARIO 2: Using COMPOSITE Pattern (Group Shapes)**

**What it does:**
- Groups multiple shapes together
- Move/resize the group as ONE unit
- Delete the whole group at once

#### **How to use ShapeGroup:**

**Single shape (what you do now):**
```java
iShape circle = new Circle(start, end, color);
addShape(circle);
```

**Grouped shapes (using Composite):**
```java
// Create individual shapes
iShape circle = new Circle(start1, end1, color1);
iShape rectangle = new Rectangle(start2, end2, color2);
iShape line = new Line(start3, end3, color3);

// Create a group and add shapes to it
ShapeGroup group = new ShapeGroup();
group.addShape(circle);
group.addShape(rectangle);
group.addShape(line);

// Add the group to the canvas
addShape((Shape) group);
group.draw(CanvasBox);

// Now you can:
// - group.setPosition(newPosition) - moves ALL shapes
// - group.setColor(newColor) - colors ALL shapes
// - group.draw(canvas) - draws ALL shapes at once
```

#### **UI Implementation for Grouping:**

**Add UI elements:**
```xml
<Button fx:id="GroupBtn" text="Group Selected" />
<Button fx:id="UngroupBtn" text="Ungroup" />
```

**In controller:**
```java
@FXML
private Button GroupBtn;

@FXML
private void handleGroupButton(ActionEvent event) {
    // Get selected shapes from ShapeList
    ObservableList<Integer> selected = ShapeList.getSelectionModel().getSelectedIndices();
    
    if (selected.size() < 2) {
        Message.setText("Select at least 2 shapes to group!");
        return;
    }
    
    // Create new group
    ShapeGroup group = new ShapeGroup();
    
    // Add selected shapes to group
    for (Integer index : selected) {
        group.addShape(shapeList.get(index));
    }
    
    // Remove original shapes from list
    for (int i = selected.size() - 1; i >= 0; i--) {
        shapeList.remove((int) selected.get(i));
    }
    
    // Add group as single shape
    shapeList.add((Shape) group);
    
    Message.setText("Grouped " + selected.size() + " shapes!");
    redraw();
}
```

---

## 🔄 COMBINING DECORATOR + COMPOSITE

**Super Powerful:**
```java
// Create a group
ShapeGroup group = new ShapeGroup();

// Add shapes to group
group.addShape(new Circle(p1, p2, Color.RED));
group.addShape(new Rectangle(p3, p4, Color.BLUE));

// Now decorate the ENTIRE GROUP with effects
iShape decoratedGroup = new ShapeWithStroke((iShape) group, 5.0, "dashed");
decoratedGroup = new ShapeWithShadow(decoratedGroup, 4.0);

// Result: All shapes in group have stroke and shadow effects!
addShape((Shape) decoratedGroup);
decoratedGroup.draw(CanvasBox);
```

---

## 📝 EXACT CODE LOCATIONS TO MODIFY

### **File 1: FXMLDocumentController.java**

**Location:** `src/paint/controller/FXMLDocumentController.java`

**Line ~280 - onMouseReleased() method:**
```java
// BEFORE:
sh = new ShapeFactory().createShape(type,start,end,ColorBox.getValue());
addShape(sh);
sh.draw(CanvasBox);

// AFTER (add decorator logic here):
sh = new ShapeFactory().createShape(type,start,end,ColorBox.getValue());
iShape decoratedShape = sh;  // Start with base shape

// Apply decorators if UI checkboxes checked
if (someCondition) {
    decoratedShape = new ShapeWithStroke(decoratedShape, ...);
}

addShape((Shape) decoratedShape);
decoratedShape.draw(CanvasBox);
```

---

## 🎓 WHY USE THESE PATTERNS?

### **Decorator Benefits:**
✅ Add effects WITHOUT creating new Shape subclasses
✅ Combine multiple effects (stroke + shadow + gradient)
✅ Apply effects at runtime dynamically
✅ Keep Shape classes unchanged

### **Composite Benefits:**
✅ Treat group as single shape
✅ Move/resize multiple shapes together
✅ Delete entire group with one operation
✅ Apply effects to entire group at once

---

## 📊 COMPARISON: Before vs After

### **Before (Without Patterns):**
```java
// Have to create separate classes for each combination:
class StrokedCircle extends Circle { } // ❌ Bad
class ShadowedStrokedCircle extends Circle { } // ❌ Nightmare
class GroupOfShapes { } // ❌ Not flexible
```

### **After (With Patterns):**
```java
// Compose dynamically:
iShape effect1 = new ShapeWithStroke(circle, 2.0);
iShape effect2 = new ShapeWithShadow(effect1, 3.0);
iShape effect3 = new ShapeWithGradient(effect2, red, blue);

// Or group:
ShapeGroup group = new ShapeGroup();
group.addShape(circle);
group.addShape(rectangle);
```

---

## 🚀 NEXT STEPS FOR YOU

1. **Compile the app:**
```powershell
cd "C:\Users\goryg\OneDrive\سطح المكتب\PaintAppProject\Javafx-Paint-Application\Paint\Paint"
& "C:\Users\goryg\OneDrive\سطح المكتب\JavaJDK\openJdk-25\bin\javac.exe" -d build/classes --module-path "C:\Users\goryg\OneDrive\سطح المكتب\javafx-sdk-21.0.3\lib" --add-modules javafx.controls,javafx.fxml -sourcepath src src\paint\Paint.java src\paint\model\*.java src\paint\controller\*.java
```

2. **Run the app:**
```powershell
& "C:\Users\goryg\OneDrive\سطح المكتب\JavaJDK\openJdk-25\bin\java.exe" --enable-native-access=javafx.graphics --module-path "C:\Users\goryg\OneDrive\سطح المكتب\javafx-sdk-21.0.3\lib" --add-modules javafx.controls,javafx.fxml -cp build/classes paint.Paint
```

3. **Modify FXMLDocumentController.java** to use decorators and composite (as shown above)

4. **Recompile and run** to see the new features in action!

---

## 💡 QUICK EXAMPLES TO TRY

### **Example 1: Stroke Only**
```java
Shape sh = new ShapeFactory().createShape("Circle", start, end, Color.RED);
iShape strokedCircle = new ShapeWithStroke((iShape)sh, 3.0, "solid");
```

### **Example 2: Shadow Only**
```java
iShape shadowedCircle = new ShapeWithShadow((iShape)sh, 5.0);
```

### **Example 3: All Effects Combined**
```java
iShape decorated = (iShape)sh;
decorated = new ShapeWithStroke(decorated, 2.0, "dashed");
decorated = new ShapeWithShadow(decorated, 3.0);
decorated = new ShapeWithGradient(decorated, Color.BLUE, Color.GREEN);
```

### **Example 4: Group Shapes**
```java
ShapeGroup group = new ShapeGroup();
group.addShape(shape1);
group.addShape(shape2);
group.addShape(shape3);
// Now treat group as single shape!
```

---

**Enjoy using Decorator and Composite patterns! 🎉**
