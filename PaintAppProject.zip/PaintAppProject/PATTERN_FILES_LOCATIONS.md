# PATTERN CLASSES - FILE STRUCTURE & LOCATIONS

## 📁 PROJECT STRUCTURE

```
PaintAppProject/
└── Javafx-Paint-Application/
    └── Paint/
        └── Paint/
            └── src/
                └── paint/
                    ├── model/
                    │   ├── iShape.java                    ← Interface (requires clone())
                    │   ├── Shape.java                     ← Abstract base shape
                    │   ├── Circle.java                    ← Concrete shape
                    │   ├── Rectangle.java                 ← Concrete shape
                    │   ├── Line.java                      ← Concrete shape
                    │   ├── Triangle.java                  ← Concrete shape
                    │   ├── Square.java                    ← Concrete shape
                    │   ├── Ellipse.java                   ← Concrete shape
                    │   │
                    │   ├── ✨ DECORATOR PATTERN:
                    │   ├── ShapeDecorator.java            ← Abstract decorator base
                    │   ├── ShapeWithStroke.java           ← Concrete decorator #1
                    │   ├── ShapeWithShadow.java           ← Concrete decorator #2
                    │   ├── ShapeWithGradient.java         ← Concrete decorator #3
                    │   │
                    │   └── 🔗 COMPOSITE PATTERN:
                    │       └── ShapeGroup.java            ← Groups multiple shapes
                    │
                    └── controller/
                        ├── FXMLDocumentController.java    ← WHERE TO USE PATTERNS
                        ├── ShapeFactory.java              ← Factory pattern
                        ├── DrawingEngine.java             ← Interface
                        ├── SaveToXML.java
                        └── LoadFromXML.java
```

---

## 🎨 DECORATOR PATTERN - DETAILED VIEW

### **ShapeDecorator.java** (Base Class)
```java
public abstract class ShapeDecorator implements iShape {
    protected iShape wrappedShape;  // ← The decorated shape
    
    public ShapeDecorator(iShape shape) {
        this.wrappedShape = shape;
    }
    
    // All methods delegate to wrappedShape
    // Subclasses override specific methods to add behavior
}
```

### **ShapeWithStroke.java** (Adds Stroke Effect)
```java
public class ShapeWithStroke extends ShapeDecorator {
    private double strokeWidth;
    private String strokeStyle;  // "solid", "dashed", "dotted"
    
    public ShapeWithStroke(iShape shape, double strokeWidth, String style) {
        super(shape);
        this.strokeWidth = strokeWidth;
        this.strokeStyle = style;
    }
    
    @Override
    public void draw(Canvas canvas) {
        // Apply stroke styling, then draw wrapped shape
    }
}
```

### **ShapeWithShadow.java** (Adds Shadow Effect)
```java
public class ShapeWithShadow extends ShapeDecorator {
    private double shadowOffsetX;
    private double shadowOffsetY;
    private Color shadowColor;
    
    public ShapeWithShadow(iShape shape, double offset) {
        super(shape);
        this.shadowOffsetX = offset;
        this.shadowOffsetY = offset;
        this.shadowColor = Color.color(0, 0, 0, 0.3);
    }
    
    @Override
    public void draw(Canvas canvas) {
        // Draw shadow, then wrapped shape
    }
}
```

### **ShapeWithGradient.java** (Adds Gradient Fill)
```java
public class ShapeWithGradient extends ShapeDecorator {
    private Color colorStart;
    private Color colorEnd;
    private boolean isHorizontal;
    
    public ShapeWithGradient(iShape shape, Color start, Color end) {
        super(shape);
        this.colorStart = start;
        this.colorEnd = end;
        this.isHorizontal = true;
    }
    
    @Override
    public void draw(Canvas canvas) {
        // Apply gradient fill, then draw wrapped shape
    }
}
```

---

## 🔗 COMPOSITE PATTERN - DETAILED VIEW

### **ShapeGroup.java** (Composite Class)
```java
public class ShapeGroup implements iShape {
    private List<iShape> shapes = new ArrayList<>();  // ← Child shapes
    
    public void addShape(iShape shape) {
        shapes.add(shape);
    }
    
    public void removeShape(iShape shape) {
        shapes.remove(shape);
    }
    
    @Override
    public void draw(Canvas canvas) {
        // Draw all child shapes
        for (iShape shape : shapes) {
            shape.draw(canvas);
        }
    }
    
    @Override
    public void setPosition(Point2D position) {
        // Set position for all child shapes
        for (iShape shape : shapes) {
            shape.setPosition(position);
        }
    }
}
```

---

## 🔄 HOW DECORATOR WRAPPING WORKS

### **Visual Flow:**

```
Original Shape:
    Circle(center, radius, RED)

Step 1 - Add Stroke:
    ShapeWithStroke(Circle(...), 3.0)
    └── wrappedShape: Circle(...)

Step 2 - Add Shadow:
    ShapeWithShadow(ShapeWithStroke(...), 4.0)
    └── wrappedShape: ShapeWithStroke(...)
        └── wrappedShape: Circle(...)

Step 3 - Add Gradient:
    ShapeWithGradient(ShapeWithShadow(...), RED, BLUE)
    └── wrappedShape: ShapeWithShadow(...)
        └── wrappedShape: ShapeWithStroke(...)
            └── wrappedShape: Circle(...)

Result: When you call draw(), it goes:
Gradient.draw()
  → applies gradient
  → calls Shadow.draw()
    → draws shadow
    → calls Stroke.draw()
      → applies stroke
      → calls Circle.draw()
        → circle is drawn with ALL effects!
```

---

## 🌳 HOW COMPOSITE WORKS

### **Visual Flow:**

```
ShapeGroup {
    └── shapes: [
        Circle(p1, p2, RED),
        Rectangle(p3, p4, BLUE),
        Line(p5, p6, GREEN)
    ]
}

When you call:
- group.draw(canvas)     → draws ALL 3 shapes
- group.setPosition(p)   → moves ALL 3 shapes
- group.setColor(color)  → colors ALL 3 shapes
- group.clone()          → clones ALL 3 shapes + group
```

---

## 📍 WHERE PATTERNS ARE USED IN THE APP

### **Location 1: FXMLDocumentController.java** (Line ~280)

#### **Current code (Factory Pattern only):**
```java
public void onMouseReleased(MouseEvent event) {
    String type = ShapeBox.getValue();
    Point2D start = new Point2D(startX, startY);
    Point2D end = new Point2D(event.getX(), event.getY());
    
    Shape sh = new ShapeFactory().createShape(
        type, 
        start, 
        end, 
        ColorBox.getValue()
    );
    addShape(sh);
    sh.draw(CanvasBox);
}
```

#### **How to add DECORATOR (Proposed modification):**
```java
public void onMouseReleased(MouseEvent event) {
    String type = ShapeBox.getValue();
    Point2D start = new Point2D(startX, startY);
    Point2D end = new Point2D(event.getX(), event.getY());
    
    // Create base shape using Factory Pattern
    Shape sh = new ShapeFactory().createShape(
        type, 
        start, 
        end, 
        ColorBox.getValue()
    );
    
    // ✨ APPLY DECORATOR PATTERN:
    iShape decoratedShape = (iShape) sh;
    
    // Add stroke if checkbox is checked
    if (addStrokeCheckbox != null && addStrokeCheckbox.isSelected()) {
        decoratedShape = new ShapeWithStroke(decoratedShape, 2.0, "solid");
    }
    
    // Add shadow if checkbox is checked
    if (addShadowCheckbox != null && addShadowCheckbox.isSelected()) {
        decoratedShape = new ShapeWithShadow(decoratedShape, 3.0);
    }
    
    // Add gradient if checkbox is checked
    if (addGradientCheckbox != null && addGradientCheckbox.isSelected()) {
        decoratedShape = new ShapeWithGradient(
            decoratedShape,
            gradientStartColor.getValue(),
            gradientEndColor.getValue()
        );
    }
    
    addShape((Shape) decoratedShape);
    decoratedShape.draw(CanvasBox);
}
```

#### **How to add COMPOSITE (Proposed modification):**
```java
@FXML
private void handleGroupButton(ActionEvent event) {
    ObservableList<Integer> selected = ShapeList.getSelectionModel().getSelectedIndices();
    
    if (selected.size() < 2) {
        Message.setText("Select at least 2 shapes!");
        return;
    }
    
    // 🔗 CREATE COMPOSITE:
    ShapeGroup group = new ShapeGroup();
    
    // Add selected shapes to group
    for (Integer index : selected) {
        group.addShape(shapeList.get(index));
    }
    
    // Remove originals and add group
    for (int i = selected.size() - 1; i >= 0; i--) {
        shapeList.remove((int) selected.get(i));
    }
    
    shapeList.add((Shape) group);
    Message.setText("Grouped " + selected.size() + " shapes!");
    redraw();
}
```

---

## 🎯 USAGE SUMMARY TABLE

| Pattern | Class | Purpose | Where Used |
|---------|-------|---------|-----------|
| **Decorator** | ShapeDecorator | Abstract base for decorators | Inherited by 3 concrete decorators |
| **Decorator** | ShapeWithStroke | Adds stroke styling | Wrap any shape |
| **Decorator** | ShapeWithShadow | Adds shadow effect | Wrap any shape (or decorated shape) |
| **Decorator** | ShapeWithGradient | Adds gradient fill | Wrap any shape (or decorated shape) |
| **Composite** | ShapeGroup | Groups multiple shapes | Treat group as single shape |

---

## 🔍 KEY FILES TO UNDERSTAND

### **Must Read:**
1. `ShapeDecorator.java` → Abstract base (2 methods)
2. `ShapeWithStroke.java` → Example concrete decorator
3. `ShapeGroup.java` → Composite implementation
4. `FXMLDocumentController.java` (Lines 270-290) → Where to use them

### **Supporting Files:**
5. `iShape.java` → Interface all must implement
6. `Shape.java` → Abstract base for original shapes
7. `ShapeFactory.java` → Creates base shapes

---

## 📝 IMPLEMENTATION CHECKLIST

- [ ] Read ShapeDecorator.java (understand abstract decorator)
- [ ] Read ShapeWithStroke.java (understand one concrete example)
- [ ] Read ShapeGroup.java (understand composite)
- [ ] Locate FXMLDocumentController.java line ~280 (onMouseReleased method)
- [ ] Add checkbox UI controls to FXML
- [ ] Modify onMouseReleased to apply decorators based on checkboxes
- [ ] Add group button to UI
- [ ] Create handleGroupButton method to use ShapeGroup
- [ ] Compile: `javac -d build/classes ...`
- [ ] Run: `java --module-path ... paint.Paint`
- [ ] Test by drawing shapes with effects and grouping

