# Code Structure Template - What to Write (NOT Changes Yet!)

## 📝 Template 1: ShapeDecorator.java (Abstract Base)

**File Location**: `src/paint/model/ShapeDecorator.java`

**Code Structure** (this is what you'll write):
```java
package paint.model;

import javafx.geometry.Point2D;
import javafx.scene.canvas.Canvas;
import javafx.scene.paint.Color;
import java.util.Map;

/**
 * Abstract base class for Decorator pattern
 * Allows adding responsibilities to shapes dynamically
 */
public abstract class ShapeDecorator implements iShape {
    
    protected iShape decoratedShape;  // The wrapped shape
    
    public ShapeDecorator(iShape shape) {
        this.decoratedShape = shape;
    }
    
    // Delegation methods - forward to wrapped shape
    @Override
    public void setPosition(Point2D position) {
        decoratedShape.setPosition(position);
    }
    
    @Override
    public Point2D getPosition() {
        return decoratedShape.getPosition();
    }
    
    @Override
    public void setColor(Color color) {
        decoratedShape.setColor(color);
    }
    
    @Override
    public Color getColor() {
        return decoratedShape.getColor();
    }
    
    @Override
    public void setFillColor(Color color) {
        decoratedShape.setFillColor(color);
    }
    
    @Override
    public Color getFillColor() {
        return decoratedShape.getFillColor();
    }
    
    @Override
    public void draw(Canvas canvas) {
        decoratedShape.draw(canvas);  // Default: just delegate
    }
    
    // Other delegated methods from iShape...
    @Override
    public void setProperties(Map<String, Double> properties) {
        decoratedShape.setProperties(properties);
    }
    
    @Override
    public Map<String, Double> getProperties() {
        return decoratedShape.getProperties();
    }
    
    // Clone method
    @Override
    public Object clone() throws CloneNotSupportedException {
        return decoratedShape.clone();
    }
}
```

**Why this structure?**
- `decoratedShape` field: Holds the wrapped shape
- Delegation methods: Forward to wrapped shape
- `draw()`: Can be overridden by concrete decorators
- Implements iShape: Can be used wherever iShape is expected

---

## 📝 Template 2: ShapeWithStroke.java (Concrete Decorator)

**File Location**: `src/paint/model/ShapeWithStroke.java`

**Code Structure** (this is what you'll write):
```java
package paint.model;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;

/**
 * Concrete decorator that adds stroke styling to shapes
 * Usage: new ShapeWithStroke(baseShape, 2.0, "solid")
 */
public class ShapeWithStroke extends ShapeDecorator {
    
    private double strokeWidth;
    private String strokeStyle;  // "solid", "dashed", "dotted"
    
    public ShapeWithStroke(iShape shape, double strokeWidth) {
        super(shape);
        this.strokeWidth = strokeWidth;
        this.strokeStyle = "solid";
    }
    
    public ShapeWithStroke(iShape shape, double strokeWidth, String strokeStyle) {
        super(shape);
        this.strokeWidth = strokeWidth;
        this.strokeStyle = strokeStyle;
    }
    
    @Override
    public void draw(Canvas canvas) {
        GraphicsContext gc = canvas.getGraphicsContext2D();
        
        // Save original settings
        double originalWidth = gc.getLineWidth();
        double[] originalDashes = gc.getLineDashes();
        
        // Apply stroke settings
        gc.setLineWidth(strokeWidth);
        
        if ("dashed".equals(strokeStyle)) {
            gc.setLineDashes(5, 5);
        } else if ("dotted".equals(strokeStyle)) {
            gc.setLineDashes(2, 3);
        } else {
            gc.setLineDashes();  // solid
        }
        
        // Draw the wrapped shape with stroke applied
        decoratedShape.draw(canvas);
        
        // Restore original settings
        gc.setLineWidth(originalWidth);
        gc.setLineDashes(originalDashes);
    }
    
    // Getters and setters
    public void setStrokeWidth(double width) {
        this.strokeWidth = width;
    }
    
    public void setStrokeStyle(String style) {
        this.strokeStyle = style;
    }
    
    public double getStrokeWidth() {
        return strokeWidth;
    }
    
    public String getStrokeStyle() {
        return strokeStyle;
    }
}
```

**Why this structure?**
- Extends ShapeDecorator: Gets all delegation methods for free
- Override `draw()`: Apply stroke, then call wrapped.draw()
- Save/restore settings: Doesn't affect other shapes
- Setters/getters: Allow runtime modification

---

## 📝 Template 3: ShapeWithShadow.java (Concrete Decorator)

**File Location**: `src/paint/model/ShapeWithShadow.java`

**Code Structure** (this is what you'll write):
```java
package paint.model;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

/**
 * Concrete decorator that adds shadow effect to shapes
 * Usage: new ShapeWithShadow(baseShape, 3.0)
 */
public class ShapeWithShadow extends ShapeDecorator {
    
    private double offsetX;
    private double offsetY;
    private Color shadowColor;
    private double shadowBlur;
    
    public ShapeWithShadow(iShape shape, double offset) {
        super(shape);
        this.offsetX = offset;
        this.offsetY = offset;
        this.shadowColor = Color.color(0, 0, 0, 0.3);  // Semi-transparent black
        this.shadowBlur = 5.0;
    }
    
    public ShapeWithShadow(iShape shape, double offsetX, double offsetY, 
                          Color shadowColor, double blur) {
        super(shape);
        this.offsetX = offsetX;
        this.offsetY = offsetY;
        this.shadowColor = shadowColor;
        this.shadowBlur = blur;
    }
    
    @Override
    public void draw(Canvas canvas) {
        GraphicsContext gc = canvas.getGraphicsContext2D();
        
        // Save original color
        javafx.scene.paint.Paint originalFill = gc.getFill();
        
        // Draw shadow first (underneath)
        gc.setFill(shadowColor);
        // Note: In real implementation, would need to translate coordinates
        // For now, this is a simplified version
        
        // Draw the actual shape on top (with original color)
        gc.setFill(originalFill);
        decoratedShape.draw(canvas);
    }
    
    public void setShadowOffset(double x, double y) {
        this.offsetX = x;
        this.offsetY = y;
    }
    
    public void setShadowColor(Color color) {
        this.shadowColor = color;
    }
}
```

**Why this structure?**
- Similar to ShapeWithStroke but for shadow effects
- Draws shadow before shape (layering)
- Settable properties (offset, color, blur)
- Delegates to wrapped shape

---

## 📝 Template 4: ShapeWithGradient.java (Concrete Decorator)

**File Location**: `src/paint/model/ShapeWithGradient.java`

**Code Structure** (this is what you'll write):
```java
package paint.model;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.scene.paint.CycleMethod;

/**
 * Concrete decorator that adds gradient fill to shapes
 * Usage: new ShapeWithGradient(baseShape, Color.RED, Color.BLUE)
 */
public class ShapeWithGradient extends ShapeDecorator {
    
    private Color colorStart;
    private Color colorEnd;
    private boolean isHorizontal;
    
    public ShapeWithGradient(iShape shape, Color start, Color end) {
        super(shape);
        this.colorStart = start;
        this.colorEnd = end;
        this.isHorizontal = true;
    }
    
    public ShapeWithGradient(iShape shape, Color start, Color end, boolean horizontal) {
        super(shape);
        this.colorStart = start;
        this.colorEnd = end;
        this.isHorizontal = horizontal;
    }
    
    @Override
    public void draw(Canvas canvas) {
        GraphicsContext gc = canvas.getGraphicsContext2D();
        
        // Save original fill
        javafx.scene.paint.Paint originalFill = gc.getFill();
        
        // Create gradient
        Stop[] stops = new Stop[] {
            new Stop(0, colorStart),
            new Stop(1, colorEnd)
        };
        
        LinearGradient gradient = new LinearGradient(
            0, 0,
            isHorizontal ? 100 : 0,
            isHorizontal ? 0 : 100,
            false,
            CycleMethod.NO_CYCLE,
            stops
        );
        
        // Apply gradient
        gc.setFill(gradient);
        
        // Draw shape with gradient
        decoratedShape.draw(canvas);
        
        // Restore original fill
        gc.setFill(originalFill);
    }
    
    public void setGradientColors(Color start, Color end) {
        this.colorStart = start;
        this.colorEnd = end;
    }
    
    public void setGradientDirection(boolean horizontal) {
        this.isHorizontal = horizontal;
    }
}
```

**Why this structure?**
- Applies gradient fill before drawing
- Restores original fill after
- Settable colors and direction
- Works with any shape

---

## 📝 Template 5: FXMLDocumentController.java Modifications

**File Location**: `src/paint/controller/FXMLDocumentController.java`

### SECTION 1: Add Imports (Top of file, around line 1-30)
```java
// Add these imports (after existing imports):
import paint.model.ShapeWithStroke;
import paint.model.ShapeWithShadow;
import paint.model.ShapeWithGradient;
```

### SECTION 2: Add @FXML Fields (Around line 30-60)
```java
// Add these fields (with other @FXML fields):

@FXML
private CheckBox strokeCheckbox;

@FXML
private TextField strokeWidthInput;

@FXML
private ComboBox<String> strokeStyleCombo;

@FXML
private CheckBox shadowCheckbox;

@FXML
private CheckBox gradientCheckbox;

@FXML
private ColorPicker gradientStartPicker;

@FXML
private ColorPicker gradientEndPicker;
```

### SECTION 3: Add Decorator Logic (In mouse handler around line 200-300)
```java
// Find method like onMouseReleased or similar
// It probably looks like:

@FXML
private void onMouseReleased(MouseEvent event) {
    // Get shape type from UI
    String shapeType = ShapeCombo.getValue();
    
    // Create base shape
    iShape shape = ShapeFactory.createShape(
        shapeType,
        startPoint,
        endPoint,
        selectedColor
    );
    
    // ========== ADD THIS SECTION ==========
    // Apply decorators based on UI selections
    
    // Apply stroke if selected
    if (strokeCheckbox != null && strokeCheckbox.isSelected()) {
        try {
            double strokeWidth = Double.parseDouble(strokeWidthInput.getText());
            String strokeStyle = strokeStyleCombo.getValue();
            shape = new ShapeWithStroke(shape, strokeWidth, strokeStyle);
        } catch (NumberFormatException e) {
            System.err.println("Invalid stroke width: " + strokeWidthInput.getText());
        }
    }
    
    // Apply shadow if selected
    if (shadowCheckbox != null && shadowCheckbox.isSelected()) {
        shape = new ShapeWithShadow(shape, 3.0);
    }
    
    // Apply gradient if selected
    if (gradientCheckbox != null && gradientCheckbox.isSelected()) {
        Color gradStart = gradientStartPicker.getValue();
        Color gradEnd = gradientEndPicker.getValue();
        if (gradStart != null && gradEnd != null) {
            shape = new ShapeWithGradient(shape, gradStart, gradEnd, true);
        }
    }
    // ========== END ADD SECTION ==========
    
    // Add to drawing
    drawingEngine.addShape(shape);
    
    // Redraw
    drawCanvas();
}
```

**Why this structure?**
- Each decorator is optional (checked before wrapping)
- Try-catch handles user input errors
- Null checks prevent NPE
- Decorators wrap in order: Gradient → Shadow → Stroke

---

## 📝 Template 6: FXMLDocument.fxml Modifications

**File Location**: `src/paint/view/FXMLDocument.fxml`

### CODE TO ADD (In your existing UI layout):
```xml
<!-- Add this section in your GridPane or VBox -->

<!-- Stroke Controls -->
<VBox spacing="10" style="-fx-border-color: #ccc; -fx-padding: 10;">
    <Label text="Stroke Options:" style="-fx-font-weight: bold;" />
    
    <CheckBox fx:id="strokeCheckbox" text="Add Stroke" />
    
    <HBox spacing="5">
        <Label text="Width:" />
        <TextField fx:id="strokeWidthInput" prefWidth="80" 
                   promptText="2.0" />
    </HBox>
    
    <HBox spacing="5">
        <Label text="Style:" />
        <ComboBox fx:id="strokeStyleCombo" prefWidth="150">
            <items>
                <FXCollections fx:factory="observableArrayList">
                    <String fx:value="solid" />
                    <String fx:value="dashed" />
                    <String fx:value="dotted" />
                </FXCollections>
            </items>
        </ComboBox>
    </HBox>
</VBox>

<!-- Shadow Controls -->
<VBox spacing="10" style="-fx-border-color: #ccc; -fx-padding: 10;">
    <Label text="Shadow Options:" style="-fx-font-weight: bold;" />
    <CheckBox fx:id="shadowCheckbox" text="Add Shadow" />
</VBox>

<!-- Gradient Controls -->
<VBox spacing="10" style="-fx-border-color: #ccc; -fx-padding: 10;">
    <Label text="Gradient Options:" style="-fx-font-weight: bold;" />
    
    <CheckBox fx:id="gradientCheckbox" text="Use Gradient" />
    
    <HBox spacing="5">
        <Label text="Start Color:" />
        <ColorPicker fx:id="gradientStartPicker" />
    </HBox>
    
    <HBox spacing="5">
        <Label text="End Color:" />
        <ColorPicker fx:id="gradientEndPicker" />
    </HBox>
</VBox>
```

**Why this structure?**
- VBox containers organize related controls
- fx:id matches @FXML fields in controller
- Spacing and styling for visual clarity
- ComboBox provides dropdown options

---

## 🎯 Order of Decorator Application (Important!)

```
User selects all three effects:
✓ Stroke checkbox = YES (2.0px, solid)
✓ Shadow checkbox = YES
✓ Gradient checkbox = YES

EXECUTION ORDER:
Step 1: iShape shape = new Circle(...)
        Shape: Circle

Step 2: shape = new ShapeWithStroke(shape, 2.0, "solid")
        Shape: ShapeWithStroke(Circle)

Step 3: shape = new ShapeWithShadow(shape, 3.0)
        Shape: ShapeWithShadow(ShapeWithStroke(Circle))

Step 4: shape = new ShapeWithGradient(shape, RED, BLUE, true)
        Shape: ShapeWithGradient(ShapeWithShadow(ShapeWithStroke(Circle)))

DRAWING EXECUTION:
shape.draw(canvas)
  ↓
ShapeWithGradient.draw(canvas)
  ├─ Apply gradient fill
  └─ Call decoratedShape.draw(canvas)
     ↓
     ShapeWithShadow.draw(canvas)
       ├─ Draw shadow
       └─ Call decoratedShape.draw(canvas)
          ↓
          ShapeWithStroke.draw(canvas)
            ├─ Apply stroke
            └─ Call decoratedShape.draw(canvas)
               ↓
               Circle.draw(canvas)
                 └─ Draw circle

RESULT: Circle with all effects! 🎨
```

---

## ✅ What NOT to Write

❌ Do NOT modify these files:
- Shape.java
- Circle.java
- Rectangle.java
- Line.java
- iShape.java
- ShapeFactory.java

❌ Do NOT create these new files:
- StrokedCircle.java
- ShadowedRectangle.java
- GradientLine.java
- (ANY shape+effect combination class)

---

## 📋 Implementation Order

### Step 1: Create decorators
1. Create ShapeDecorator.java
2. Create ShapeWithStroke.java
3. Create ShapeWithShadow.java
4. Create ShapeWithGradient.java

### Step 2: Modify controller
1. Add imports to FXMLDocumentController.java
2. Add @FXML fields to FXMLDocumentController.java
3. Add decorator logic to mouse handler

### Step 3: Add UI
1. Add UI controls to FXMLDocument.fxml

### Step 4: Test
1. Run application
2. Enable checkboxes to test effects
3. Verify decorators work correctly

---

