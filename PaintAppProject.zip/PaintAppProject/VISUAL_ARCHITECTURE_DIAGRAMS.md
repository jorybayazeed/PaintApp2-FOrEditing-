# Visual Architecture Diagrams - DECORATOR & COMPOSITE Patterns

## 🎨 PATTERN #1: DECORATOR - Architecture Diagrams

### Current Architecture (Before Decorator)
```
┌─────────────────────────────────────────────────────────┐
│                 FXMLDocumentController                   │
│                                                           │
│  Creates shapes using:                                   │
│  ShapeFactory.createShape(type, start, end, color)      │
└──────────────────────┬──────────────────────────────────┘
                       │
                       ▼
        ┌──────────────────────────┐
        │   ShapeFactory           │
        │  (Factory Pattern)       │
        └──────────────┬───────────┘
                       │
          ┌────────────┼────────────┐
          │            │            │
          ▼            ▼            ▼
    ┌─────────┐  ┌──────────┐  ┌─────────┐
    │ Circle  │  │Rectangle │  │  Line   │
    └─────────┘  └──────────┘  └─────────┘
   (all implement iShape interface)

❌ Problem: To add styling, need new classes:
   - CircleWithStroke
   - CircleWithShadow
   - RectangleWithStroke
   - RectangleWithGradient
   - ... (EXPLOSION!)
```

---

### New Architecture (With Decorator)
```
┌────────────────────────────────────────────────────────┐
│            FXMLDocumentController                       │
│                                                         │
│  1. Create base shape                                  │
│  2. Wrap with decorators based on UI selections       │
│  3. Add decorated shape to engine                     │
└──────────────────┬──────────────────────────────────┘
                   │
        ┌──────────┴──────────┐
        │                     │
        ▼                     ▼
┌──────────────────┐    ┌──────────────────┐
│  ShapeFactory    │    │  Decorators      │
│  (Factory)       │    │  (Decorator)     │
│  Creates base    │    │  Wraps base      │
│  shapes          │    │  Adds effects    │
└────────┬─────────┘    └──────────────────┘
         │
         ▼
    Base Shape
    (Circle/Rectangle/Line)
         │
         │ wrapped by
         ▼
    ┌──────────────────────────┐
    │ ShapeWithStroke          │ ◄─ Decorator 1
    │ (wraps base shape)       │
    └────────────┬─────────────┘
                 │ wrapped by
                 ▼
    ┌──────────────────────────┐
    │ ShapeWithShadow          │ ◄─ Decorator 2
    │ (wraps Stroke wrapper)   │
    └────────────┬─────────────┘
                 │ wrapped by
                 ▼
    ┌──────────────────────────┐
    │ ShapeWithGradient        │ ◄─ Decorator 3
    │ (wraps Shadow wrapper)   │
    └──────────────────────────┘

✅ Result: Any combination without new classes!
```

---

### Object Composition at Runtime
```
User selects:
  ☑ Add Stroke
  ☑ Add Shadow
  ☑ Use Gradient

EXECUTION SEQUENCE:
┌─────────────────────────────────────────────────────┐
│ 1. iShape shape = new Circle(...)                   │
│    Creates: CIRCLE                                   │
└─────────────────────────────────────────────────────┘
              │
              │ "I want stroke!"
              ▼
┌─────────────────────────────────────────────────────┐
│ 2. shape = new ShapeWithStroke(shape, 2.0)          │
│    Creates: STROKE(CIRCLE)                          │
└─────────────────────────────────────────────────────┘
              │
              │ "I want shadow too!"
              ▼
┌─────────────────────────────────────────────────────┐
│ 3. shape = new ShapeWithShadow(shape, 3.0)          │
│    Creates: SHADOW(STROKE(CIRCLE))                  │
└─────────────────────────────────────────────────────┘
              │
              │ "I want gradient!"
              ▼
┌─────────────────────────────────────────────────────┐
│ 4. shape = new ShapeWithGradient(shape, c1, c2)     │
│    Creates: GRADIENT(SHADOW(STROKE(CIRCLE)))        │
└─────────────────────────────────────────────────────┘
              │
              │ shape.draw(canvas)
              ▼
    RENDERING LAYER BY LAYER:
    ────────────────────────────
    1. Render gradient fill
    2. Render shadow underneath
    3. Apply stroke outline
    4. Display circle

RESULT: Beautiful layered shape! 🎨
```

---

### Data Flow Diagram (Decorator Pattern)
```
USER ACTIONS
    │
    ├─→ Check "Add Stroke" checkbox ─→ strokeCheckbox.isSelected() = true
    ├─→ Enter "2.0" in width field ─→ strokeWidthInput.getText() = "2.0"
    ├─→ Select "dashed" style ─→ strokeStyleCombo.getValue() = "dashed"
    ├─→ Check "Add Shadow" ─→ shadowCheckbox.isSelected() = true
    ├─→ Check "Use Gradient" ─→ gradientCheckbox.isSelected() = true
    ├─→ Select start color ─→ gradientStartPicker.getValue() = RED
    ├─→ Select end color ─→ gradientEndPicker.getValue() = BLUE
    └─→ Release mouse to draw
              │
              ▼
    FXMLDocumentController.onMouseReleased()
              │
              ├─→ ShapeFactory.createShape()
              │   Returns: iShape (base shape)
              │
              ├─→ if (strokeCheckbox.isSelected())
              │   shape = new ShapeWithStroke(shape, 2.0, "dashed")
              │
              ├─→ if (shadowCheckbox.isSelected())
              │   shape = new ShapeWithShadow(shape, 3.0)
              │
              ├─→ if (gradientCheckbox.isSelected())
              │   shape = new ShapeWithGradient(shape, RED, BLUE)
              │
              └─→ drawingEngine.addShape(shape)
                     │
                     ▼
              engine.shapes.add(shape)
                     │
                     ▼
              drawCanvas()
                     │
                     ▼
              For each shape: shape.draw(canvas)
                     │
                     ▼
         FINAL RENDERED SHAPE WITH ALL EFFECTS!
```

---

## 🎨 PATTERN #2: COMPOSITE - Architecture Diagrams

### When Composite Becomes Useful
```
SCENARIO: User wants to group shapes

❌ WITHOUT Composite:
   Shapes are independent
   ├─ Circle
   ├─ Rectangle
   ├─ Line
   └─ (Each drawn separately, moved separately)

✅ WITH Composite:
   Shapes can be grouped
   └─ Group A
       ├─ Circle      ┐
       ├─ Rectangle   ├─ Move ALL together
       ├─ Line        │
       └─ Ellipse     ┘
       
   AND groups can contain groups:
   └─ Super Group
       ├─ Group A
       │  ├─ Circle
       │  ├─ Rectangle
       │  └─ Line
       └─ Group B
          ├─ Triangle
          └─ Square
```

---

### Class Hierarchy (Composite Pattern)
```
                    ┌──────────────┐
                    │   iShape     │
                    │ (interface)  │
                    └──────────────┘
                          ▲
            ┌─────────────┬┴─────────────┐
            │             │              │
            │             │              │
    ┌───────┴────┐  ┌────┴─────┐  ┌────┴──────┐
    │  Shape     │  │  Shapes  │  │ShapeGroup │
    │ (abstract) │  │ (concrete)│  │(composite)│
    └────┬───────┘  └──────────┘  └───────────┘
         │                              ▲
    ┌────┴─────┬──────┬─────┐          │
    │           │      │     │          │
┌───┴──┐  ┌────┴─┐  ┌─┴───┐┌┴────┐    │
│Circle│  │  Rect│  │Line ││Tri  │    │
└──────┘  └──────┘  └─────┘└─────┘    │
                                        │
           Group contains other Groups──┘
```

---

### Recursive Structure (Composite)
```
ShapeGroup (represents entire drawing)
│
├─ ShapeGroup (Group A)
│  │
│  ├─ Circle (at 100, 100)
│  ├─ Rectangle (at 150, 100)
│  └─ ShapeGroup (Subgroup A1)
│     │
│     ├─ Line (at 200, 100)
│     └─ Triangle (at 250, 100)
│
├─ ShapeGroup (Group B)
│  │
│  ├─ Ellipse (at 300, 100)
│  └─ Square (at 350, 100)
│
└─ Rectangle (at 400, 100) - Individual shape

When you call: rootGroup.draw(canvas)
It draws EVERYTHING recursively! ✅
```

---

### Composite Method Calls
```
rootGroup.draw(canvas)
    │
    ├─→ groupA.draw(canvas)
    │   │
    │   ├─→ circle.draw(canvas)
    │   ├─→ rectangle.draw(canvas)
    │   └─→ subgroupA1.draw(canvas)
    │       │
    │       ├─→ line.draw(canvas)
    │       └─→ triangle.draw(canvas)
    │
    ├─→ groupB.draw(canvas)
    │   │
    │   ├─→ ellipse.draw(canvas)
    │   └─→ square.draw(canvas)
    │
    └─→ rectangle.draw(canvas)

RESULT: All shapes rendered in hierarchy! 🎨
```

---

## 📊 Comparison: Before vs After

### BEFORE: No Decorator, No Composite
```
Classes needed:
- Circle (1)
- Rectangle (1)
- Line (1)
- ... base shapes

Total: ~8 classes for shapes

Styling limitations:
❌ Can't add stroke to existing circle
❌ Can't combine stroke + shadow
❌ Can't group shapes
❌ Code modification for each effect
```

---

### AFTER: With Decorator & Composite
```
Classes created:
- Circle (existing)
- Rectangle (existing)
- Line (existing)
- ShapeDecorator (abstract base)
- ShapeWithStroke (decorator)
- ShapeWithShadow (decorator)
- ShapeWithGradient (decorator)
- ShapeGroup (composite - future)

Total: ~8 base + unlimited decorators!

Styling capabilities:
✅ Add effects to any shape
✅ Combine multiple effects
✅ Group shapes together
✅ Add effects without code changes
```

---

## 🔄 Method Call Flow (How Drawing Works)

### With Decorators:
```
drawCanvas() called by user
    │
    ▼
for each shape in drawingEngine.shapes:
    │
    └─→ if (shape is ShapeWithGradient)
        │
        └─→ ShapeWithGradient.draw(canvas)
            │
            ├─→ Create and apply gradient fill
            │
            ├─→ Call wrapped.draw(canvas)
            │   │
            │   └─→ if (wrapped is ShapeWithShadow)
            │       │
            │       ├─→ Draw shadow background
            │       │
            │       └─→ Call wrapped.draw(canvas)
            │           │
            │           └─→ if (wrapped is ShapeWithStroke)
            │               │
            │               ├─→ Set stroke properties
            │               │
            │               └─→ Call wrapped.draw(canvas)
            │                   │
            │                   └─→ Circle.draw(canvas)
            │                       ✅ Finally draws the base shape!
            │
            ├─→ Restore gradient fill
            │
            └─→ Return to canvas

RESULT: Shape drawn with ALL effects applied! 🎨
```

---

## 📍 File Structure After Implementation

```
Paint/
│
├── src/
│   └── paint/
│       │
│       ├── model/
│       │   ├── iShape.java (interface - unchanged)
│       │   ├── Shape.java (abstract base - unchanged)
│       │   ├── Circle.java (unchanged)
│       │   ├── Rectangle.java (unchanged)
│       │   ├── Line.java (unchanged)
│       │   ├── Triangle.java (unchanged)
│       │   ├── Square.java (unchanged)
│       │   ├── Ellipse.java (unchanged)
│       │   │
│       │   ├── ShapeDecorator.java ✨ NEW (abstract)
│       │   ├── ShapeWithStroke.java ✨ NEW (decorator)
│       │   ├── ShapeWithShadow.java ✨ NEW (decorator)
│       │   ├── ShapeWithGradient.java ✨ NEW (decorator)
│       │   │
│       │   └── ShapeGroup.java 🟡 (future - composite)
│       │
│       ├── controller/
│       │   ├── FXMLDocumentController.java (EDIT - add imports & decorator code)
│       │   ├── DrawingEngine.java (unchanged)
│       │   ├── ShapeFactory.java (unchanged)
│       │   └── ...
│       │
│       └── view/
│           ├── FXMLDocument.fxml (EDIT - add UI controls)
│           └── styles.css
│
└── test/
    └── ...
```

---

## ✅ Implementation Checklist

### Phase 1: Setup (NOW)
- [ ] Create ShapeDecorator.java (abstract base)
- [ ] Create ShapeWithStroke.java (concrete decorator 1)
- [ ] Create ShapeWithShadow.java (concrete decorator 2)
- [ ] Create ShapeWithGradient.java (concrete decorator 3)
- [ ] Add imports to FXMLDocumentController.java
- [ ] Add @FXML fields to FXMLDocumentController.java
- [ ] Add decorator code to mouse handler
- [ ] Add UI controls to FXMLDocument.fxml

### Phase 2: Enhancement (LATER)
- [ ] Create ShapeGroup.java (when grouping needed)
- [ ] Add grouping method to controller
- [ ] Add group buttons to UI
- [ ] Test grouping functionality

---

