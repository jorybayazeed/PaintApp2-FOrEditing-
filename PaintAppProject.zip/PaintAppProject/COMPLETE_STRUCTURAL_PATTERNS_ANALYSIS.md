# Complete Structural Patterns Analysis for Paint App

## 📚 ALL 7 Structural Patterns Overview

### 1. **ADAPTER** ❌ Not Suitable
**Purpose**: Convert interface of one class into another interface clients expect
**Problem it solves**: Making incompatible interfaces work together

**Why NOT for Paint App:**
- ❌ All shapes already implement `iShape` interface uniformly
- ❌ No third-party APIs or incompatible interfaces to bridge
- ❌ No "legacy" code that needs adaptation
- ❌ Would add unnecessary abstraction layer

**When you WOULD use it:**
```
Example: Adapting Android Canvas API to JavaFX Canvas API
// Your app doesn't need this!
```

---

### 2. **BRIDGE** ⚠️ Somewhat Applicable (Not Recommended)
**Purpose**: Decouple abstraction from its implementation
**Problem it solves**: Avoiding permanent binding between abstraction and implementation

**Why NOT ideal for Paint App:**
- ⚠️ Your shapes already separate interface (iShape) from implementation (Circle, Rectangle)
- ⚠️ Would be over-engineering for current needs
- ⚠️ Adds complexity without clear benefit
- ❌ You're not trying to vary both abstraction AND implementation independently

**When you WOULD use it:**
```
Example: Different rendering engines (OpenGL, Canvas)
// You only use Canvas, so Bridge is overkill
```

---

### 3. **COMPOSITE** ⚠️ Potentially Useful (Future Enhancement)
**Purpose**: Compose objects into tree structures; treat individual objects and compositions uniformly
**Problem it solves**: Working with part-whole hierarchies

**Why it COULD work:**
- ✅ Could group shapes together (ShapeGroup containing multiple shapes)
- ✅ Would allow nested groups (group within group)
- ✅ Uniform interface for single shapes and groups

**Why NOT right now:**
- ❌ Your Paint app doesn't show grouping functionality
- ⚠️ Would complicate the current simple shape drawing
- ⚠️ Better as a future enhancement when grouping is needed

**Use case example:**
```
Group g1 = new Group();
g1.add(new Circle(...));
g1.add(new Rectangle(...));

Group g2 = new Group();
g2.add(g1);  // Group within group!
g2.add(new Line(...));

g2.draw(canvas);  // All nested shapes drawn!
```

---

### 4. **DECORATOR** ✅✅ MOST RECOMMENDED (#1)
**Purpose**: Attach additional responsibilities to object dynamically
**Problem it solves**: Adding features without modifying original classes

**Why PERFECT for Paint App:**
- ✅✅ Add styling effects to ANY shape at runtime
- ✅✅ Compose multiple effects on same shape
- ✅✅ NO class explosion (no StrokedCircle, ShadowedRectangle classes)
- ✅✅ Open/Closed Principle: Extend without modifying
- ✅✅ Single Responsibility: Each decorator = one concern
- ✅✅ Easy to add new effects later

**Real Use Cases for Paint App:**
```
1. Stroke styling (width, dashed, solid)
2. Shadow/glow effects
3. Gradient fills
4. Border decorations
5. Rotation/scale transforms
6. Animation effects
7. Transparency/opacity
```

**Solves this problem:**
```
❌ WITHOUT Decorator:
- ShapeWithStroke { }
- ShapeWithShadow { }
- ShapeWithStrokeAndShadow { }  ← Class explosion!
- ShapeWithGradient { }
- ShapeWithStrokeAndGradientAndShadow { }  ← Nightmare!

✅ WITH Decorator:
- new ShapeWithStroke(
    new ShapeWithShadow(
      new ShapeWithGradient(baseShape)
    )
  )
```

---

### 5. **FAÇADE** ❌ Not Suitable
**Purpose**: Provide unified, simplified interface to complex subsystem
**Problem it solves**: Hiding complexity of multiple classes

**Why NOT for Paint App:**
- ❌ Your interfaces are already simple and clean
- ❌ Drawing engine isn't complex enough to need simplification
- ❌ No "subsystem" to hide
- ❌ Would just add an unnecessary wrapper

**When you WOULD use it:**
```
Example: Complex drawing library with 50+ classes
// Your Paint app is elegantly simple!
```

---

### 6. **FLYWEIGHT** ⚠️ Minor Benefit (Not Essential)
**Purpose**: Share common state among multiple objects to save memory
**Problem it solves**: Reducing memory when creating many similar objects

**Why it COULD help:**
- ✅ If drawing 10,000+ shapes, shared properties save memory
- ⚠️ Current Paint app draws manageable number of shapes
- ⚠️ Performance/memory isn't a bottleneck in your app

**Why NOT priority:**
- ❌ Your Paint app has limited number of shapes
- ❌ RAM isn't a concern for typical drawing tasks
- ⚠️ Adds complexity with shared state management
- ⚠️ Better optimized locally if needed later

**Only useful if:**
```
Drawing millions of shapes where each takes memory
// Your app: dozens to hundreds max
```

---

### 7. **PROXY** ❌ Not Suitable
**Purpose**: Provide surrogate or placeholder for another object
**Problem it solves**: Lazy loading, access control, logging, caching

**Why NOT for Paint App:**
- ❌ No lazy loading needs (shapes drawn immediately)
- ❌ No access control needed (shapes are simple objects)
- ❌ No logging requirements
- ❌ No performance bottleneck requiring caching

**When you WOULD use it:**
```
Example: Lazy-loading images from network
// Your shapes don't need loading!
```

---

## 🏆 TOP 2 RECOMMENDED PATTERNS FOR PAINT APP

### **#1 - DECORATOR (PRIMARY CHOICE)** ⭐⭐⭐⭐⭐

**Why it's #1:**
1. **Perfect for styling shapes** - Add stroke, shadow, gradient dynamically
2. **No modifications needed** - Existing Shape classes unchanged
3. **Scalable** - Add new decorators endlessly
4. **Flexible composition** - Mix and match effects
5. **Clean architecture** - Single responsibility per decorator
6. **Future-proof** - Easy to add new effects without refactoring

**Recommended Use Cases:**
- ✅ Stroke styling (width, pattern, color)
- ✅ Shadow/glow effects
- ✅ Gradient fills
- ✅ Border/outline effects
- ✅ Animation effects
- ✅ Transparency/opacity control
- ✅ Rotation/scale transforms

**Implementation Priority: NOW** 🔴 (Do this first)

---

### **#2 - COMPOSITE (SECONDARY, FUTURE)** ⭐⭐⭐

**Why it's #2:**
1. **Prepares for grouping** - When users need to group shapes
2. **Hierarchical structure** - Nested groups support
3. **Uniform interface** - Single and composite shapes same API
4. **Scalable growth** - Extends naturally when feature requested

**Potential Use Cases:**
- ✅ Group multiple shapes together
- ✅ Nested groups (group within group)
- ✅ Move/transform groups as one unit
- ✅ Apply effects to entire group
- ✅ Lock/unlock group edits

**Implementation Priority: LATER** 🟡 (Add when users ask for grouping)

---

## 📊 Comparison Table

| Aspect | Decorator | Composite | Bridge | Adapter | Façade | Flyweight | Proxy |
|--------|-----------|-----------|--------|---------|--------|-----------|-------|
| **Solves Paint needs?** | ✅✅✅ YES | ✅ YES | ⚠️ Maybe | ❌ NO | ❌ NO | ⚠️ Maybe | ❌ NO |
| **Adds styling?** | ✅✅✅ | ⚠️ Indirect | ❌ NO | ❌ NO | ❌ NO | ❌ NO | ❌ NO |
| **Simplifies code?** | ✅✅✅ | ✅ YES | ⚠️ NO | ❌ NO | ⚠️ Maybe | ❌ NO | ❌ NO |
| **Easy to add effects?** | ✅✅✅ | ❌ NO | ❌ NO | ❌ NO | ❌ NO | ❌ NO | ❌ NO |
| **Complexity added** | 🟢 Low | 🟡 Medium | 🔴 High | 🟡 Medium | 🟡 Medium | 🔴 High | 🟡 Medium |
| **Needed NOW?** | 🟢 YES | 🟡 Later | 🔴 NO | 🔴 NO | 🔴 NO | 🔴 NO | 🔴 NO |
| **Difficulty** | 🟢 Easy | 🟡 Medium | 🔴 Hard | 🟡 Medium | 🟡 Medium | 🔴 Hard | 🟡 Medium |

---

## 🎯 Decision Matrix: Why These 2?

```
DECORATOR #1:
├── Solves immediate need: Styling shapes ✅
├── Improves architecture: Open/Closed Principle ✅
├── Minimal complexity: Easy to implement ✅
├── Scales naturally: Add more decorators ✅
└── Required NOW: YES ✅

COMPOSITE #2:
├── Future enhancement: When grouping needed ✅
├── Hierarchical support: Nested groups ✅
├── Natural extension: From current design ✅
├── Not urgent: Can wait for feature request ⚠️
└── Required NOW: NO (but prepare for it)
```

---

## 🚫 What We're Explicitly Rejecting & Why

| Pattern | Final Decision | Key Reason |
|---------|----------------|-----------|
| Adapter | ❌ REJECT | No incompatible interfaces to bridge |
| Bridge | ❌ REJECT | Over-engineering; already have clean separation |
| Façade | ❌ REJECT | Architecture already simple and clean |
| Flyweight | ❌ REJECT | Not a memory-constrained application |
| Proxy | ❌ REJECT | No lazy loading, access control, or caching needs |

---

# IMPLEMENTATION GUIDE FOR THE 2 PATTERNS

## PATTERN #1: DECORATOR - WHERE TO EDIT & WHY

### Step 1: Create Abstract Decorator Base Class
**File to Create**: `src/paint/model/ShapeDecorator.java`

**Why this location?**
- Lives with other model classes (Circle, Rectangle, etc.)
- Part of domain model layer
- Abstract class pattern

**What it should contain:**
```java
public abstract class ShapeDecorator implements iShape {
    protected iShape decoratedShape;  // Composition
    
    public ShapeDecorator(iShape shape) {
        this.decoratedShape = shape;
    }
    
    // Delegate all methods to wrapped shape
    @Override
    public void setPosition(Point2D position) {
        decoratedShape.setPosition(position);
    }
    
    @Override
    public void draw(Canvas canvas) {
        decoratedShape.draw(canvas);
    }
    
    // ... other delegated methods ...
}
```

**Why this structure?**
- `implements iShape` - Decorator IS-A Shape (polymorphism)
- `decoratedShape` field - Decorator HAS-A Shape (composition)
- Delegates by default - Subclasses override specific methods
- Follows Liskov Substitution Principle

---

### Step 2: Create Concrete Decorators

#### **Decorator #1: ShapeWithStroke**
**File to Create**: `src/paint/model/ShapeWithStroke.java`

**Why needed?**
- Users want to control stroke width
- Users want stroke patterns (solid, dashed, dotted)
- Multiple shapes need same styling

**What to override:**
```java
public class ShapeWithStroke extends ShapeDecorator {
    private double strokeWidth;
    private String strokeStyle;
    
    @Override
    public void draw(Canvas canvas) {
        GraphicsContext gc = canvas.getGraphicsContext2D();
        
        // Save original settings
        double originalWidth = gc.getLineWidth();
        
        // Apply stroke styling
        gc.setLineWidth(strokeWidth);
        if ("dashed".equals(strokeStyle)) {
            gc.setLineDashes(5, 5);
        }
        
        // Draw the decorated shape
        decoratedShape.draw(canvas);
        
        // Restore original settings
        gc.setLineWidth(originalWidth);
    }
}
```

**Why override only draw()?**
- Position, color, fill handled by base shape
- Only stroke rendering differs
- DRY Principle - don't repeat position/color code

---

#### **Decorator #2: ShapeWithShadow**
**File to Create**: `src/paint/model/ShapeWithShadow.java`

**Why needed?**
- Add depth/visual effect to shapes
- Shadows enhance UI aesthetics
- Apply to any shape type

**What to override:**
```java
public class ShapeWithShadow extends ShapeDecorator {
    private double offsetX, offsetY;
    private Color shadowColor;
    
    @Override
    public void draw(Canvas canvas) {
        GraphicsContext gc = canvas.getGraphicsContext2D();
        
        // Draw shadow first (offset position)
        Color originalFill = gc.getFill();
        gc.setFill(shadowColor);
        
        // Draw shape offset (shadow effect)
        drawShadowVersion(canvas);
        
        // Restore color and draw actual shape
        gc.setFill(originalFill);
        decoratedShape.draw(canvas);
    }
}
```

**Why this approach?**
- Shadow drawn first (behind shape)
- Original shape drawn on top
- Creates layering effect

---

#### **Decorator #3: ShapeWithGradient**
**File to Create**: `src/paint/model/ShapeWithGradient.java`

**Why needed?**
- Users want gradient fills instead of solid colors
- Modern UI aesthetic
- Works with any shape

**What to override:**
```java
public class ShapeWithGradient extends ShapeDecorator {
    private Color colorStart, colorEnd;
    private boolean isHorizontal;
    
    @Override
    public void draw(Canvas canvas) {
        GraphicsContext gc = canvas.getGraphicsContext2D();
        
        // Create gradient
        LinearGradient gradient = new LinearGradient(
            0, 0,
            isHorizontal ? 100 : 0,
            isHorizontal ? 0 : 100,
            false,
            CycleMethod.NO_CYCLE,
            new Stop(0, colorStart),
            new Stop(1, colorEnd)
        );
        
        // Apply gradient fill
        Paint originalFill = gc.getFill();
        gc.setFill(gradient);
        
        decoratedShape.draw(canvas);
        
        gc.setFill(originalFill);
    }
}
```

---

### Step 3: Edit FXMLDocumentController - WHERE TO ADD DECORATOR USAGE

**File to Edit**: `src/paint/controller/FXMLDocumentController.java`

**Location #1 - Add Imports at Top:**
```java
// Around line 1-30, add these imports:
import paint.model.ShapeWithStroke;
import paint.model.ShapeWithShadow;
import paint.model.ShapeWithGradient;
```

**Why?**
- Makes decorator classes available in controller
- Clean imports section

---

**Location #2 - Find Mouse Event Handler (Shape Creation)**

**Search for**: `onMouseReleased` or method that handles shape drawing completion

**Current code looks like:**
```java
@FXML
private void onMouseReleased(MouseEvent event) {
    // Current code:
    iShape shape = ShapeFactory.createShape(
        selectedShapeType,
        startPoint,
        endPoint,
        selectedColor
    );
    
    drawingEngine.addShape(shape);
    drawCanvas();
}
```

**Where to insert decorator code:**
```java
@FXML
private void onMouseReleased(MouseEvent event) {
    // CREATE BASE SHAPE (unchanged)
    iShape shape = ShapeFactory.createShape(
        selectedShapeType,
        startPoint,
        endPoint,
        selectedColor
    );
    
    // ⬇️ INSERT DECORATOR CODE HERE ⬇️
    // Check UI controls and apply decorators
    
    if (strokeCheckbox != null && strokeCheckbox.isSelected()) {
        double width = Double.parseDouble(strokeWidthInput.getText());
        String style = strokeStyleCombo.getValue();
        shape = new ShapeWithStroke(shape, width, style);
    }
    
    if (shadowCheckbox != null && shadowCheckbox.isSelected()) {
        shape = new ShapeWithShadow(shape, 3.0, 3.0, Color.BLACK, 5.0);
    }
    
    if (gradientCheckbox != null && gradientCheckbox.isSelected()) {
        Color start = gradientStartPicker.getValue();
        Color end = gradientEndPicker.getValue();
        shape = new ShapeWithGradient(shape, start, end, true);
    }
    
    // ⬆️ END DECORATOR CODE ⬆️
    
    drawingEngine.addShape(shape);
    drawCanvas();
}
```

**Why at this location?**
- After shape creation but before adding to engine
- Decorators wrap base shape
- Clean separation of concerns

---

**Location #3 - Add UI Controls in FXMLDocument.fxml**

**File to Edit**: `src/paint/view/FXMLDocument.fxml`

**Where to add:**
```xml
<!-- Add these controls to your existing UI, around other controls -->

<!-- Stroke Controls -->
<CheckBox fx:id="strokeCheckbox" text="Add Stroke"/>
<TextField fx:id="strokeWidthInput" promptText="2.0" prefWidth="50"/>
<ComboBox fx:id="strokeStyleCombo">
    <items>
        <FXCollections fx:factory="observableArrayList">
            <String fx:value="solid"/>
            <String fx:value="dashed"/>
            <String fx:value="dotted"/>
        </FXCollections>
    </items>
</ComboBox>

<!-- Shadow Controls -->
<CheckBox fx:id="shadowCheckbox" text="Add Shadow"/>

<!-- Gradient Controls -->
<CheckBox fx:id="gradientCheckbox" text="Use Gradient"/>
<ColorPicker fx:id="gradientStartPicker"/>
<ColorPicker fx:id="gradientEndPicker"/>
```

**Why in FXML?**
- UI definition separates from logic
- fx:id links to controller fields
- Easy to modify UI without touching Java

---

**Location #4 - Declare UI Fields in FXMLDocumentController**

**File to Edit**: `src/paint/controller/FXMLDocumentController.java`

**Where to add (around line 30-50 with other @FXML fields):**
```java
// UI Controls for Decorator Pattern
@FXML
private CheckBox strokeCheckbox;

@FXML
private TextField strokeWidthInput;

@FXML
private ComboBox<String> strokeStyleCombo;

@FXML
private CheckBox shadowCheckbox;

@FXML
private CheckBox gradientCheckbox;

@FXML
private ColorPicker gradientStartPicker;

@FXML
private ColorPicker gradientEndPicker;
```

**Why @FXML annotation?**
- Tells FXML loader to inject these fields
- Connects FXML elements to Java code
- No explicit initialization needed

---

## PATTERN #2: COMPOSITE - WHERE TO EDIT & WHY (FUTURE)

**⚠️ DO NOT IMPLEMENT NOW - Just showing where you WOULD**

### When to implement:
- ✅ When users ask: "Can I group shapes?"
- ✅ When you need nested groups
- ✅ When you want transform groups together

### Step 1: Create ShapeGroup Class
**File to Create (LATER)**: `src/paint/model/ShapeGroup.java`

**Why this location?**
- Lives with other model classes
- Implements iShape like other shapes
- IS-A Shape, but contains multiple shapes

**Structure (pseudo-code):**
```java
public class ShapeGroup implements iShape {
    private List<iShape> shapes = new ArrayList<>();
    
    public void addShape(iShape shape) {
        shapes.add(shape);
    }
    
    @Override
    public void draw(Canvas canvas) {
        // Draw all shapes in group
        for (iShape shape : shapes) {
            shape.draw(canvas);
        }
    }
    
    @Override
    public void setPosition(Point2D position) {
        // Move all shapes by offset
        for (iShape shape : shapes) {
            shape.setPosition(position);
        }
    }
}
```

### Step 2: Use in FXMLDocumentController (LATER)
**Location**: Same `onMouseReleased` or new `groupShapes()` method

```java
private void groupShapes(List<iShape> selectedShapes) {
    ShapeGroup group = new ShapeGroup();
    
    for (iShape shape : selectedShapes) {
        group.addShape(shape);
    }
    
    drawingEngine.addShape(group);
}
```

**Why later?**
- Not in current requirements
- Can add when feature requested
- Doesn't break existing code

---

# 🎓 Summary Table: What & Where to Edit

| Pattern | What to Create | Where to Edit | Priority | Why |
|---------|---|---|---|---|
| **DECORATOR** | ShapeDecorator.java | FXMLDocumentController.java | 🔴 NOW | Enable styling features |
| **DECORATOR** | ShapeWithStroke.java | FXMLDocument.fxml | 🔴 NOW | Stroke styling UI |
| **DECORATOR** | ShapeWithShadow.java | Add @FXML fields | 🔴 NOW | Shadow UI controls |
| **DECORATOR** | ShapeWithGradient.java | Add imports | 🔴 NOW | Gradient UI binding |
| **COMPOSITE** | ShapeGroup.java | (Future method) | 🟡 LATER | Grouping feature |
| **COMPOSITE** | (Group logic) | (Future controller) | 🟡 LATER | Select & group |

---

# ❌ What NOT to Edit

| File | Why NOT modify |
|------|---|
| Shape.java | ✅ Keep unchanged - Decorator handles styling |
| Circle.java | ✅ Keep unchanged - Works with decorators |
| Rectangle.java | ✅ Keep unchanged - Works with decorators |
| Line.java | ✅ Keep unchanged - Works with decorators |
| Triangle.java | ✅ Keep unchanged - Works with decorators |
| iShape.java | ✅ Keep unchanged - Decorators implement it |
| ShapeFactory.java | ✅ Keep unchanged - Creates base shapes |

**Why?**
- Open/Closed Principle: Extend with decorators, not modifications
- Existing code works as-is
- Reduces bugs and side effects
- Makes code easier to maintain

---

